"""Sharpe-ratio comparison tests for Kernel-IQ portfolio outputs."""
from __future__ import annotations

import math
import os
import sys
from datetime import datetime

import numpy as np
import pandas as pd
from scipy.stats import norm

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
try:
    from defaults import DEFAULTS as _D
except Exception:
    _D = {}

def _bool_env(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or str(raw).strip() == "":
        return default
    return str(raw).strip().lower() in {"1", "true", "yes", "y", "on"}


def _int_list_env(name: str, default: list[int]) -> list[int]:
    raw = os.environ.get(name)
    if raw is None or str(raw).strip() == "":
        return default
    vals: list[int] = []
    for part in str(raw).replace(";", ",").split(","):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals or default


def _str_list_env(name: str) -> list[str] | None:
    raw = os.environ.get(name)
    if raw is None or str(raw).strip() == "":
        return None
    vals = [p.strip() for p in str(raw).replace(";", ",").split(",") if p.strip()]
    return vals or None




def _resolve_oos_dir() -> str:
    raw = os.environ.get("DIQ_OUTPUT_DIR", (_D or {}).get("diq_output_dir", "OOS_results"))
    return raw if os.path.isabs(raw) else os.path.join(BASE_DIR, raw)


def _resolve_output_dir() -> str:
    raw = os.environ.get("DIQ_SR_TEST_DIR", "SR_test_results")
    return raw if os.path.isabs(raw) else os.path.join(BASE_DIR, raw)


STRATEGY_LABEL = "maxSharpe"
OOS_DIR = _resolve_oos_dir()
OUTPUT_DIR = _resolve_output_dir()
os.makedirs(OUTPUT_DIR, exist_ok=True)

SR_MODE = os.environ.get("WIQ_SR_MODE", "light").strip().lower()
if SR_MODE not in {"light", "full"}:
    SR_MODE = "light"

VERBOSE = _bool_env("WIQ_SR_VERBOSE", False)
N_BOOT = int(os.environ.get("WIQ_SR_N_BOOT", "1000" if SR_MODE == "light" else "5000"))
DO_FULL_BOOTSTRAP = _bool_env("WIQ_SR_FULL_BOOTSTRAP", True)
DO_ROLLING_BOOTSTRAP = _bool_env("WIQ_SR_ROLLING_BOOTSTRAP", SR_MODE == "full")
DO_ROLLING_TESTS = _bool_env("WIQ_SR_ROLLING_TESTS", True)
ROLLING_WINDOW = int(os.environ.get("WIQ_SR_ROLLING_WINDOW", "36"))
ROLLING_STEPS = _int_list_env("WIQ_SR_ROLLING_STEPS", [3] if SR_MODE == "light" else [1, 3])
NW_LAGS = _int_list_env("WIQ_SR_NW_LAGS", [6])
BLOCK_LENGTHS_MEAN = _int_list_env("WIQ_SR_BLOCK_LENGTHS_MEAN", [12])
BLOCK_LENGTH_SR = int(os.environ.get("WIQ_SR_BLOCK_LENGTH_SR", "12"))

STRATEGIES = [
    "WIQ", "GS1", "GS2", "GS3", "GS_opt", "LS1", "LS2", "LS3",
    "LS4", "LS5", "NLS6", "NLS7", "NLS8", "HC", "CRE", "SRE", "SRE_opt"
]
KEY_COMPARATORS = ["GS1", "GS2", "GS_opt", "LS1", "LS2", "LS3", "LS5", "HC", "CRE"]
REQUESTED_COMPARATORS = _str_list_env("WIQ_SR_COMPARATORS")

RF_CSV = os.environ.get("DIQ_RF_CSV", (_D or {}).get("rf_csv", "DGS3MO_monthly_rf.csv"))
RF_CSV = RF_CSV if os.path.isabs(RF_CSV) else os.path.join(BASE_DIR, RF_CSV)
RF_DATE_COL = "DATE"
RF_VALUE_COL = "DGS3MO"
RF_ALIGN_METH = "ffill"


class Tee:
    def __init__(self, *files):
        self.files = files

    def write(self, obj):
        for f in self.files:
            f.write(obj)

    def flush(self):
        for f in self.files:
            f.flush()


def _console(msg: str) -> None:
    sys.__stdout__.write(msg + "\n")
    sys.__stdout__.flush()


def load_rf_series(index: pd.DatetimeIndex) -> pd.Series:
    if not os.path.exists(RF_CSV):
        raise FileNotFoundError(f"Risk-free CSV not found at {RF_CSV}")
    rf_df = pd.read_csv(RF_CSV, parse_dates=[RF_DATE_COL])
    rf_df = rf_df.set_index(RF_DATE_COL).sort_index()
    if RF_VALUE_COL not in rf_df.columns:
        raise KeyError(f"Column '{RF_VALUE_COL}' not found in {RF_CSV}")
    rf = rf_df[RF_VALUE_COL].astype(float)
    return rf.reindex(index, method=RF_ALIGN_METH)


def load_portfolio_excess_returns(strategy: str) -> pd.Series:
    fname = os.path.join(OOS_DIR, f"{strategy}_value.csv")
    if not os.path.exists(fname):
        raise FileNotFoundError(f"Value file for {strategy} not found: {fname}")
    df = pd.read_csv(fname, parse_dates=["date"]).set_index("date").sort_index()
    if STRATEGY_LABEL not in df.columns:
        raise KeyError(f"{STRATEGY_LABEL!r} column not found in {fname}. Columns available: {list(df.columns)}")
    prc = df[STRATEGY_LABEL].resample("ME", label="right").last()
    rets = prc.pct_change().dropna()
    rf = load_rf_series(rets.index)
    mask = rf.notna()
    ex_rets = rets[mask] - rf[mask]
    ex_rets.name = strategy
    return ex_rets


def load_all_excess_returns() -> pd.DataFrame:
    series_dict = {}
    for strat in STRATEGIES:
        try:
            series_dict[strat] = load_portfolio_excess_returns(strat)
            print(f"[load] Loaded excess returns for {strat} ({len(series_dict[strat])} months)")
        except FileNotFoundError:
            pass
        except Exception as e:
            print(f"[load] ERROR loading {strat}: {e}")
    if not series_dict:
        raise RuntimeError(f"No strategies loaded. Check STRATEGIES and {OOS_DIR}.")
    df = pd.concat(series_dict.values(), axis=1, join="inner").sort_index()
    print(f"[load] Final aligned excess-return panel shape: {df.shape}")
    return df


def compute_full_sample_sharpe(ex_ret: pd.Series) -> float:
    sigma = ex_ret.std(ddof=1)
    if sigma == 0 or np.isnan(sigma):
        return float("nan")
    return float(np.sqrt(12.0) * ex_ret.mean() / sigma)


def compute_rolling_sharpe(ex_ret: pd.Series, window: int, step: int = 1) -> pd.Series:
    mu = ex_ret.rolling(window).mean()
    sigma = ex_ret.rolling(window).std(ddof=1)
    sr = (np.sqrt(12.0) * mu / sigma).dropna()
    return sr.iloc[::step] if step > 1 else sr


def newey_west_se(x: np.ndarray, max_lag: int) -> float:
    x = np.asarray(x, dtype=float)
    T = x.shape[0]
    if T <= 1:
        return float("nan")
    u = x - x.mean()
    var_hat = np.mean(u * u)
    for lag in range(1, max_lag + 1):
        if lag >= T:
            break
        cov = np.mean(u[lag:] * u[:-lag])
        weight = 1.0 - lag / (max_lag + 1.0)
        var_hat += 2.0 * weight * cov
    return float(math.sqrt(max(var_hat, 0.0) / T))


def moving_block_bootstrap_mean(x: np.ndarray, block_length: int, n_boot: int, random_state: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(random_state)
    x = np.asarray(x, dtype=float)
    T = x.shape[0]
    if T <= 1 or n_boot <= 0:
        return np.array([np.nan])
    block_length = min(max(int(block_length), 1), T)
    n_blocks = math.ceil(T / block_length)
    start_indices = np.arange(0, T - block_length + 1)
    boot_means = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        starts = rng.choice(start_indices, size=n_blocks, replace=True)
        boot_means[b] = np.concatenate([x[s:s + block_length] for s in starts], axis=0)[:T].mean()
    return boot_means


def moving_block_bootstrap_sharpe_diff(pair_returns: np.ndarray, block_length: int, n_boot: int, random_state: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(random_state)
    x = np.asarray(pair_returns, dtype=float)
    T = x.shape[0]
    if T <= 1 or n_boot <= 0:
        return np.array([np.nan])
    block_length = min(max(int(block_length), 1), T)
    n_blocks = math.ceil(T / block_length)
    start_indices = np.arange(0, T - block_length + 1)
    boot_diffs = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        starts = rng.choice(start_indices, size=n_blocks, replace=True)
        x_star = np.concatenate([x[s:s + block_length, :] for s in starts], axis=0)[:T, :]
        mu = x_star.mean(axis=0)
        sigma = x_star.std(axis=0, ddof=1)
        sr = np.where(sigma == 0.0, np.nan, np.sqrt(12.0) * mu / sigma)
        boot_diffs[b] = sr[0] - sr[1]
    return boot_diffs


def test_full_sample_mean_diff(ex_df: pd.DataFrame, bench: str, comp: str, nw_lag: int) -> dict:
    series = ex_df[[bench, comp]].dropna()
    d = series[bench] - series[comp]
    d_np = d.to_numpy()
    T = len(d_np)
    mean_diff = float(d_np.mean()) if T else float("nan")
    se_naive = float(d_np.std(ddof=1) / math.sqrt(T)) if T > 1 else float("nan")
    se_nw = float(newey_west_se(d_np, nw_lag)) if T > 1 else float("nan")
    t_naive = mean_diff / se_naive if se_naive and not np.isnan(se_naive) else float("nan")
    t_nw = mean_diff / se_nw if se_nw and not np.isnan(se_nw) else float("nan")
    return {
        "T": T,
        "mean_diff": mean_diff,
        "se_naive": se_naive,
        "se_nw": se_nw,
        "t_naive": t_naive,
        "t_nw": t_nw,
        "p_naive": float(2 * (1 - norm.cdf(abs(t_naive)))) if not np.isnan(t_naive) else float("nan"),
        "p_nw": float(2 * (1 - norm.cdf(abs(t_nw)))) if not np.isnan(t_nw) else float("nan"),
    }


def test_full_sample_sharpe_diff(ex_df: pd.DataFrame, bench: str, comp: str, block_length: int, n_boot: int, random_state: int | None = 12345) -> dict:
    series = ex_df[[bench, comp]].dropna()
    R = series.to_numpy()
    T = R.shape[0]
    mu = R.mean(axis=0)
    sigma = R.std(axis=0, ddof=1)
    sr = np.where(sigma == 0.0, np.nan, np.sqrt(12.0) * mu / sigma)
    sr_bench, sr_comp = float(sr[0]), float(sr[1])
    sr_diff = float(sr_bench - sr_comp)
    out = {
        "T": T,
        "SR_bench": sr_bench,
        "SR_comp": sr_comp,
        "SR_diff": sr_diff,
        "boot_ci_lower": float("nan"),
        "boot_ci_upper": float("nan"),
        "boot_p_two": float("nan"),
        "boot_p_one": float("nan"),
    }
    if DO_FULL_BOOTSTRAP:
        boot = moving_block_bootstrap_sharpe_diff(R, block_length=block_length, n_boot=n_boot, random_state=random_state)
        out.update({
            "boot_ci_lower": float(np.nanquantile(boot, 0.025)),
            "boot_ci_upper": float(np.nanquantile(boot, 0.975)),
            "boot_p_two": float(2 * min(np.nanmean(boot <= 0.0), np.nanmean(boot >= 0.0))),
            "boot_p_one": float(np.nanmean(boot <= 0.0)),
        })
    return out


def test_rolling_sharpe_diff(rolling_sr_bench: pd.Series, rolling_sr_comp: pd.Series, label_bench: str, label_comp: str, nw_lag: int, block_length: int, random_state: int | None = 12345) -> dict:
    df = pd.concat([rolling_sr_bench.rename(label_bench), rolling_sr_comp.rename(label_comp)], axis=1, join="inner").dropna()
    d = df[label_bench] - df[label_comp]
    d_np = d.to_numpy()
    T = len(d_np)
    mean_diff = float(d_np.mean()) if T else float("nan")
    out = {
        "T": T,
        "mean_diff": mean_diff,
        "se_naive": float("nan"),
        "se_nw": float("nan"),
        "t_naive": float("nan"),
        "t_nw": float("nan"),
        "p_naive_two": float("nan"),
        "p_nw_two": float("nan"),
        "p_nw_one": float("nan"),
        "boot_ci_lower": float("nan"),
        "boot_ci_upper": float("nan"),
        "p_boot_one": float("nan"),
    }
    if T <= 1:
        return out
    se_naive = float(d_np.std(ddof=1) / math.sqrt(T))
    se_nw = float(newey_west_se(d_np, nw_lag))
    t_naive = mean_diff / se_naive if se_naive else float("nan")
    t_nw = mean_diff / se_nw if se_nw else float("nan")
    out.update({
        "se_naive": se_naive,
        "se_nw": se_nw,
        "t_naive": t_naive,
        "t_nw": t_nw,
        "p_naive_two": float(2 * (1 - norm.cdf(abs(t_naive)))) if not np.isnan(t_naive) else float("nan"),
        "p_nw_two": float(2 * (1 - norm.cdf(abs(t_nw)))) if not np.isnan(t_nw) else float("nan"),
        "p_nw_one": float(1 - norm.cdf(t_nw)) if not np.isnan(t_nw) else float("nan"),
    })
    if DO_ROLLING_BOOTSTRAP:
        boot = moving_block_bootstrap_mean(d_np, block_length, N_BOOT, random_state=random_state)
        out.update({
            "boot_ci_lower": float(np.nanquantile(boot, 0.025)),
            "boot_ci_upper": float(np.nanquantile(boot, 0.975)),
            "p_boot_one": float(np.nanmean(boot <= 0.0)),
        })
    return out


def _comparators_for(loaded: list[str]) -> list[str]:
    if REQUESTED_COMPARATORS is not None:
        requested = REQUESTED_COMPARATORS
    elif SR_MODE == "light":
        requested = KEY_COMPARATORS
    else:
        requested = [s for s in loaded if s != "WIQ"]
    return [c for c in requested if c in loaded and c != "WIQ"]


def main() -> None:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(OUTPUT_DIR, f"sr_console_log_{timestamp}.txt")
    log_file = open(log_path, "w", encoding="utf-8")
    original_stdout = sys.stdout
    sys.stdout = Tee(original_stdout, log_file) if VERBOSE else log_file

    _console(f"[wiq_sr_tests] Running mode={SR_MODE}, n_boot={N_BOOT}, output={OUTPUT_DIR}")
    _console(f"[wiq_sr_tests] Detailed log: {log_path}")
    try:
        print(f"[config] mode={SR_MODE}, n_boot={N_BOOT}")
        print(f"[config] full_bootstrap={DO_FULL_BOOTSTRAP}, rolling_tests={DO_ROLLING_TESTS}, rolling_bootstrap={DO_ROLLING_BOOTSTRAP}")
        print(f"[config] rolling_steps={ROLLING_STEPS}, comparators={REQUESTED_COMPARATORS or ('key' if SR_MODE == 'light' else 'all')}")

        ex_df = load_all_excess_returns()
        loaded = list(ex_df.columns)
        full_sharpes = {s: compute_full_sample_sharpe(ex_df[s]) for s in loaded}
        pd.DataFrame({"strategy": list(full_sharpes), "full_sample_sharpe": list(full_sharpes.values())}).to_csv(
            os.path.join(OUTPUT_DIR, "full_sample_sharpes.csv"), index=False
        )

        rolling_srs: dict[int, dict[str, pd.Series]] = {}
        if DO_ROLLING_TESTS:
            for step in ROLLING_STEPS:
                rolling_srs[step] = {s: compute_rolling_sharpe(ex_df[s], ROLLING_WINDOW, step=step) for s in loaded}

        comps = _comparators_for(loaded)
        pair_full_rows: list[dict] = []
        pair_roll_rows: list[dict] = []
        print(f"[main] WIQ comparators: {comps}")

        if "WIQ" in loaded:
            for comp in comps:
                res_full = test_full_sample_mean_diff(ex_df, "WIQ", comp, nw_lag=NW_LAGS[0])
                res_sr = test_full_sample_sharpe_diff(ex_df, "WIQ", comp, block_length=BLOCK_LENGTH_SR, n_boot=N_BOOT)
                pair_full_rows.append({
                    "benchmark": "WIQ",
                    "comparator": comp,
                    "T": res_full["T"],
                    "mean_diff": res_full["mean_diff"],
                    "se_naive": res_full["se_naive"],
                    "t_naive": res_full["t_naive"],
                    "p_naive_two": res_full["p_naive"],
                    "se_nw": res_full["se_nw"],
                    "t_nw": res_full["t_nw"],
                    "p_nw_two": res_full["p_nw"],
                    "SR_bench": res_sr["SR_bench"],
                    "SR_comp": res_sr["SR_comp"],
                    "SR_diff": res_sr["SR_diff"],
                    "boot_ci_lower": res_sr["boot_ci_lower"],
                    "boot_ci_upper": res_sr["boot_ci_upper"],
                    "boot_p_two": res_sr["boot_p_two"],
                    "boot_p_one": res_sr["boot_p_one"],
                })
                if DO_ROLLING_TESTS:
                    for step in ROLLING_STEPS:
                        for nw_lag in NW_LAGS:
                            for blk in BLOCK_LENGTHS_MEAN:
                                res_roll = test_rolling_sharpe_diff(
                                    rolling_srs[step]["WIQ"], rolling_srs[step][comp],
                                    "WIQ", comp, nw_lag=nw_lag, block_length=blk, random_state=12345,
                                )
                                pair_roll_rows.append({
                                    "benchmark": "WIQ",
                                    "comparator": comp,
                                    "step": step,
                                    "nw_lag": nw_lag,
                                    "block_length": blk,
                                    **res_roll,
                                })

        pd.DataFrame(pair_full_rows).to_csv(os.path.join(OUTPUT_DIR, "pairwise_full_sample_results.csv"), index=False)
        pd.DataFrame(pair_roll_rows).to_csv(os.path.join(OUTPUT_DIR, "pairwise_rolling_results.csv"), index=False)
        print(f"[main] CSV results written to: {OUTPUT_DIR}")
    finally:
        sys.stdout = original_stdout
        log_file.close()
    _console("[wiq_sr_tests] Done.")


if __name__ == "__main__":
    main()
