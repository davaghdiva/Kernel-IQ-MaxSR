"""
Name    : gs_sre_optuna.py
Author  : William Smyth & Layla Abu Khalaf
Contact : drwss.academy@gmail.com
Date    : 26/12/2025
Desc    : Lightweight Optuna search for GS_opt (Gerber threshold)
          and SRE_opt (RMT2 alpha) using the same rolling portfolio
          objective as the main experiment.
"""

import json
import os
import numpy as np
import pandas as pd
from defaults import DEFAULTS
from diq_mvo_optimizer import gerber_cov_stat, RMT2
from mvo_utils import (
    BacktestConfig,
    MVOSettings,
    _load_prices_subset,
    _ensure_monthly_prices,
    _load_rf_aligned,
    annualized_sharpe,
    annualized_variance,
    annualized_volatility,
    solve_max_sharpe,
    TransCost,
)

try:
    import optuna
    _HAVE_OPTUNA = True
except Exception:
    optuna = None
    _HAVE_OPTUNA = False


def _script_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__))


N_TRIALS = int(os.environ.get("GS_SRE_N_TRIALS", DEFAULTS.get("n_trials_gs_sre", 100)))


def _objective_summary_value(ret_series: pd.Series, rf_series: pd.Series | None = None) -> float:
    return float(annualized_sharpe(ret_series, rf_series))


def _study_direction() -> str:
    return "maximize"




def _clip_eval_window(ret_ser: pd.Series) -> pd.Series:
    b = DEFAULTS.get("begin_date")
    e = DEFAULTS.get("end_date")
    if b or e:
        return ret_ser.loc[b:e]
    return ret_ser


def _load_insample_prices() -> pd.DataFrame:
    """Load the in-sample price panel with optional prehistory warm-up.

    begin_date / end_date define the scored in-sample evaluation window, not the
    start of the raw history loaded from disk.
    """
    prcs = _load_prices_subset(DEFAULTS["prices_csv"], n_assets=DEFAULTS["n_assets"])
    b = DEFAULTS.get("begin_date")
    e = DEFAULTS.get("end_date")
    if not (b or e):
        return prcs

    if b and bool(DEFAULTS.get("tuning_use_prehistory_warmup", True)):
        begin_period = pd.Period(str(b), freq="M")
        warmup_rets = _aligned_eval_start_idx(prcs.shape[1])
        load_begin_period = begin_period - (warmup_rets + 1)
        prcs = prcs.loc[str(load_begin_period):e]

        rets = prcs.pct_change().dropna(axis=0)
        if len(rets) <= warmup_rets:
            raise ValueError(
                f"Insufficient in-sample history for aligned warm-up. Need more than {warmup_rets} return rows before first scored month {b}."
            )
        first_scored = pd.Period(rets.index[warmup_rets], freq="M")
        if first_scored > begin_period:
            raise ValueError(
                f"Insufficient prehistory to make begin_date={b} the first scored IS month. "
                f"Earliest feasible scored month with the available data is {first_scored}."
            )
        return prcs

    return prcs.loc[b:e]

def _aligned_eval_start_idx(n_assets: int) -> int:
    """
    Common in-sample evaluation start used to keep GS_opt and SRE_opt
    on the same scoring dates as WIQ when long-vol scaling is active.
    """
    lookback = int(DEFAULTS["lookback"])
    if not bool(DEFAULTS.get("align_tuning_eval_with_wiq", True)):
        return lookback
    mode = str(DEFAULTS.get("wiq_T_mode", "fixed"))
    if mode == "q_ratio":
        q = float(DEFAULTS.get("wiq_q", 2.0))
        t_live = int(np.ceil(q * float(n_assets)))
    else:
        t_live = lookback
    t_scale = int(DEFAULTS.get("wiq_m", 3)) * int(t_live)
    return max(lookback, t_scale)


# generic backtests for GS/SRE using the same MVO machinery as the main experiment
def backtest_gs_mvo(
    prcs: pd.DataFrame,
    threshold: float,
    bt_cfg: BacktestConfig,
):
    """Monthly portfolio backtest with Gerber covariance at fixed threshold."""
    prcs_m = _ensure_monthly_prices(prcs.copy())
    rets_m = prcs_m.pct_change().dropna()
    dates = rets_m.index
    symbols = prcs_m.columns.tolist()

    rf_m = _load_rf_aligned(dates)
    rets_excess = rets_m.sub(rf_m, axis=0).dropna() if rf_m is not None else rets_m.copy()
    optimisation_rets = rets_excess

    tc = TransCost(c_bps=bt_cfg.cost_bps)
    values = []
    metric_rets = []
    prev_weights = np.zeros(len(symbols), dtype=float)
    V = float(bt_cfg.initial_value)

    eval_start_idx = max(int(bt_cfg.lookback), _aligned_eval_start_idx(len(symbols)))
    for t in range(eval_start_idx, len(rets_m)):
        window_rets = rets_m.iloc[t - bt_cfg.lookback: t]
        window_opt = optimisation_rets.iloc[t - bt_cfg.lookback: t]
        r_next_raw = rets_m.iloc[t].values.astype(float)
        r_next_metric = optimisation_rets.iloc[t].values.astype(float)

        cov_m, _ = gerber_cov_stat(window_rets.values, threshold=float(threshold))

        settings = MVOSettings(cost_bps=bt_cfg.cost_bps)
        w_new = solve_max_sharpe(window_opt, cov_m, prev_weights, settings)

        old_w = dict(zip(symbols, prev_weights))
        new_w = dict(zip(symbols, w_new))
        drag = tc.get_cost(new_weights=new_w, old_weights=old_w)
        V_after_cost = V * (1.0 - float(drag))

        port_ret_raw = float(np.dot(w_new, r_next_raw))
        V = V_after_cost * (1.0 + port_ret_raw)

        port_ret_metric = float(np.dot(w_new, r_next_metric))
        prev_weights = w_new.copy()

        values.append((dates[t], V))
        metric_rets.append((dates[t], port_ret_metric))

    df_values = pd.DataFrame(values, columns=["date", "GS_opt"]).set_index("date")
    ret_m = pd.Series(
        data=[x[1] for x in metric_rets],
        index=pd.DatetimeIndex([x[0] for x in metric_rets]),
        name="GS_opt",
    )
    rf_eval = _load_rf_aligned(ret_m.index)
    if rf_eval is not None:
        rf_eval = rf_eval.reindex(ret_m.index).ffill().rename("rf")

    ret_m = _clip_eval_window(ret_m)
    if rf_eval is not None:
        rf_eval = rf_eval.reindex(ret_m.index).ffill().rename("rf")
    ret_m = _clip_eval_window(ret_m)
    if rf_eval is not None:
        rf_eval = rf_eval.reindex(ret_m.index).ffill().rename("rf")
    return df_values, ret_m, rf_eval


def backtest_sre_mvo(
    prcs: pd.DataFrame,
    alpha: float,
    bt_cfg: BacktestConfig,
):
    """Monthly portfolio backtest with SRE (RMT2) at fixed alpha."""
    prcs_m = _ensure_monthly_prices(prcs.copy())
    rets_m = prcs_m.pct_change().dropna()
    dates = rets_m.index
    symbols = prcs_m.columns.tolist()

    rf_m = _load_rf_aligned(dates)
    rets_excess = rets_m.sub(rf_m, axis=0).dropna() if rf_m is not None else rets_m.copy()
    optimisation_rets = rets_excess

    tc = TransCost(c_bps=bt_cfg.cost_bps)
    values = []
    metric_rets = []
    prev_weights = np.zeros(len(symbols), dtype=float)
    V = float(bt_cfg.initial_value)

    eval_start_idx = max(int(bt_cfg.lookback), _aligned_eval_start_idx(len(symbols)))
    for t in range(eval_start_idx, len(rets_m)):
        window_rets = rets_m.iloc[t - bt_cfg.lookback: t]
        window_opt = optimisation_rets.iloc[t - bt_cfg.lookback: t]
        r_next_raw = rets_m.iloc[t].values.astype(float)
        r_next_metric = optimisation_rets.iloc[t].values.astype(float)

        cov_m, _ = RMT2(window_rets.values, alpha=float(alpha))

        settings = MVOSettings(cost_bps=bt_cfg.cost_bps)
        w_new = solve_max_sharpe(window_opt, cov_m, prev_weights, settings)

        old_w = dict(zip(symbols, prev_weights))
        new_w = dict(zip(symbols, w_new))
        drag = tc.get_cost(new_weights=new_w, old_weights=old_w)
        V_after_cost = V * (1.0 - float(drag))

        port_ret_raw = float(np.dot(w_new, r_next_raw))
        V = V_after_cost * (1.0 + port_ret_raw)

        port_ret_metric = float(np.dot(w_new, r_next_metric))
        prev_weights = w_new.copy()

        values.append((dates[t], V))
        metric_rets.append((dates[t], port_ret_metric))

    df_values = pd.DataFrame(values, columns=["date", "SRE_opt"]).set_index("date")
    ret_m = pd.Series(
        data=[x[1] for x in metric_rets],
        index=pd.DatetimeIndex([x[0] for x in metric_rets]),
        name="SRE_opt",
    )
    rf_eval = _load_rf_aligned(ret_m.index)
    if rf_eval is not None:
        rf_eval = rf_eval.reindex(ret_m.index).ffill().rename("rf")

    return df_values, ret_m, rf_eval


def _optimize_gs(prcs: pd.DataFrame, bt_cfg: BacktestConfig):
    if not _HAVE_OPTUNA:
        raise RuntimeError("Optuna is not available but is required for GS_opt tuning.")

    seed = int(DEFAULTS.get("seed", 123))

    def objective(trial):
        thr = trial.suggest_float("threshold", 0.0, 1.0)
        _, ret_m, rf_m = backtest_gs_mvo(prcs, thr, bt_cfg)
        return _objective_summary_value(ret_m, rf_m)

    study = optuna.create_study(direction=_study_direction())
    study.sampler = optuna.samplers.TPESampler(seed=seed, multivariate=True, group=True)
    n_startup = max(5, int(0.2 * N_TRIALS))
    study.pruner = optuna.pruners.MedianPruner(n_startup_trials=n_startup)

    study.optimize(objective, n_trials=N_TRIALS)

    best_thr = float(study.best_params["threshold"])
    best_val = float(study.best_value)

    return {"threshold": best_thr}, best_val


def _optimize_sre(prcs: pd.DataFrame, bt_cfg: BacktestConfig):
    if not _HAVE_OPTUNA:
        raise RuntimeError("Optuna is not available but is required for SRE_opt tuning.")

    seed = int(DEFAULTS.get("seed", 123))

    def objective(trial):
        a = trial.suggest_float("alpha", 0.0, 1.0)
        _, ret_m, rf_m = backtest_sre_mvo(prcs, a, bt_cfg)
        return _objective_summary_value(ret_m, rf_m)

    study = optuna.create_study(direction=_study_direction())
    study.sampler = optuna.samplers.TPESampler(seed=seed, multivariate=True, group=True)
    n_startup = max(5, int(0.2 * N_TRIALS))
    study.pruner = optuna.pruners.MedianPruner(n_startup_trials=n_startup)

    study.optimize(objective, n_trials=N_TRIALS)

    best_alpha = float(study.best_params["alpha"])
    best_val = float(study.best_value)

    return {"alpha": best_alpha}, best_val


def main():
    prcs = _load_insample_prices()

    bt_cfg = BacktestConfig(
        lookback=int(DEFAULTS["lookback"]),
        cost_bps=float(DEFAULTS["cost_bps"]),
    )

    results = {}
    metric_name = "Sharpe"

    aligned_idx = _aligned_eval_start_idx(prcs.shape[1])
    print(f"[gs_sre_optuna] Common in-sample evaluation start index: {aligned_idx} (lookback={DEFAULTS['lookback']}, align_with_wiq={bool(DEFAULTS.get('align_tuning_eval_with_wiq', True))})")
    print(f"[gs_sre_optuna] Starting GS_opt tuning with {N_TRIALS} trials...")
    gs_params, gs_value = _optimize_gs(prcs, bt_cfg)
    results["GS_opt"] = dict(params=gs_params, objective_value=gs_value)

    print(f"[gs_sre_optuna] Starting SRE_opt tuning with {N_TRIALS} trials...")
    sre_params, sre_value = _optimize_sre(prcs, bt_cfg)
    results["SRE_opt"] = dict(params=sre_params, objective_value=sre_value)

    export = DEFAULTS.get("export_json", {})
    gs_name = os.environ.get("GS_OPT_PARAMS_JSON", export.get("GS_opt", "gs_opt_params.json"))
    sre_name = os.environ.get("SRE_OPT_PARAMS_JSON", export.get("SRE_opt", "sre_opt_params.json"))

    gs_path = gs_name if os.path.isabs(gs_name) else os.path.join(_script_dir(), gs_name)
    sre_path = sre_name if os.path.isabs(sre_name) else os.path.join(_script_dir(), sre_name)

    with open(gs_path, "w") as f:
        json.dump(gs_params, f, indent=2)
    with open(sre_path, "w") as f:
        json.dump(sre_params, f, indent=2)

    print(f"[gs_sre_optuna] GS_opt best {metric_name}={gs_value:.6f}; wrote {gs_path}")
    print(f"[gs_sre_optuna] SRE_opt best {metric_name}={sre_value:.6f}; wrote {sre_path}")

    print("\n[gs_sre_optuna] Summary:")
    for name, res in results.items():
        print(f"  {name}: {metric_name}={res['objective_value']:.6f}, params={res['params']}")


if __name__ == "__main__":
    main()
