#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${PROJECT_DIR}"

NUM_SEEDS="${1:-100}"
SEED_START="${SEED_START:-1000}"
SR_MODE="${SR_MODE:-light}"
WIQ_TRIALS="${WIQ_TRIALS:-}"
GS_SRE_TRIALS="${GS_SRE_TRIALS:-}"

if [[ ! -x ".venv/bin/python3" ]]; then
  bash scripts/setup_linux_venv.sh
fi
source .venv/bin/activate

extra_args=()
if [[ -n "${WIQ_TRIALS}" ]]; then extra_args+=(--wiq-trials "${WIQ_TRIALS}"); fi
if [[ -n "${GS_SRE_TRIALS}" ]]; then extra_args+=(--gs-sre-trials "${GS_SRE_TRIALS}"); fi

log_file="maxSharpe_${NUM_SEEDS}seed_run.log"
echo "Running maximum-Sharpe study with ${NUM_SEEDS} seeds. Log: ${log_file}"
python3 run_project.py   --fresh   --seed-start "${SEED_START}"   --num-seeds "${NUM_SEEDS}"   --sr-mode "${SR_MODE}"   "${extra_args[@]}" 2>&1 | tee "${log_file}"

python3 build_analysis_pack.py 2>&1 | tee build_analysis_pack.log

echo
echo "Finished. Analysis packs are in:"
echo "  ${PROJECT_DIR}/analysis_packs"
