#!/usr/bin/env bash
set -euo pipefail
python3 build_analysis_pack.py "$@"
