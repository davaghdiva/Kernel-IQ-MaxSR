#!/usr/bin/env bash
set -euo pipefail

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "Error: required command '$1' not found." >&2; exit 1; }
}

need_cmd python3
need_cmd gnome-terminal

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DESKTOP="${HOME}/Desktop"
RUN_ROOT="${DESKTOP}/Kernel_IQ_maxSharpe_run_$(date +%Y%m%d_%H%M%S)"
BATCH_PREFIX="KernelIQ_batch"
SR_MODE="${SR_MODE:-light}"

SEED_RANGES=(
  "1 1000 1019"
  "2 1020 1039"
  "3 1040 1059"
  "4 1060 1079"
  "5 1080 1099"
)

mkdir -p "${RUN_ROOT}"
echo "Run root: ${RUN_ROOT}"

cp -a "${SOURCE_DIR}" "${RUN_ROOT}/${BATCH_PREFIX}_1"
rm -rf "${RUN_ROOT}/${BATCH_PREFIX}_1/.venv" "${RUN_ROOT}/${BATCH_PREFIX}_1/outputs" "${RUN_ROOT}/${BATCH_PREFIX}_1/analysis_packs"
for i in 2 3 4 5; do
  cp -a "${RUN_ROOT}/${BATCH_PREFIX}_1" "${RUN_ROOT}/${BATCH_PREFIX}_${i}"
done

echo "Setting up Python environments in all five batch folders ..."
for i in 1 2 3 4 5; do
  d="${RUN_ROOT}/${BATCH_PREFIX}_${i}"
  (cd "${d}" && bash scripts/setup_linux_venv.sh)
done

launch_batch() {
  local idx="$1"
  local start_seed="$2"
  local end_seed="$3"
  local dir="${RUN_ROOT}/${BATCH_PREFIX}_${idx}"
  local cmd
  cmd=$(cat <<EOF
cd "$dir"
source .venv/bin/activate
if bash -o pipefail -c 'python3 run_ensemble.py --seeds \$(seq ${start_seed} ${end_seed}) --fresh --sr-mode ${SR_MODE} 2>&1 | tee "run_batch_${idx}.log"'; then
  echo
  echo "Batch ${idx} finished successfully."
  sleep 2
else
  status=\$?
  echo
  echo "Batch ${idx} failed with status \$status."
  read -r -p "Press Enter to close this window..."
  exit \$status
fi
EOF
)
  gnome-terminal --wait --title="Kernel-IQ batch ${idx} (${start_seed}-${end_seed})" -- bash -lc "${cmd}"
}

echo
 echo "Launching five seed batches ..."
pids=()
for spec in "${SEED_RANGES[@]}"; do
  read -r idx start_seed end_seed <<<"${spec}"
  launch_batch "${idx}" "${start_seed}" "${end_seed}" &
  pids+=("$!")
  sleep 1
done

fail=0
for pid in "${pids[@]}"; do
  if ! wait "$pid"; then fail=1; fi
done
if [[ "${fail}" -ne 0 ]]; then
  echo "One or more batches failed." >&2
  exit 1
fi

echo "Merging seed folders into batch 1 ..."
MASTER_DIR="${RUN_ROOT}/${BATCH_PREFIX}_1"
cd "${MASTER_DIR}"
source .venv/bin/activate
python3 merge_seed_runs.py   "${RUN_ROOT}/${BATCH_PREFIX}_2"   "${RUN_ROOT}/${BATCH_PREFIX}_3"   "${RUN_ROOT}/${BATCH_PREFIX}_4"   "${RUN_ROOT}/${BATCH_PREFIX}_5"   --replace 2>&1 | tee merge_seed_runs.log
python3 aggregate_ensemble.py 2>&1 | tee aggregate_ensemble.log
python3 build_analysis_pack.py 2>&1 | tee build_analysis_pack.log

BUNDLE=$(ls -1t analysis_packs/*.zip | head -1 || true)

echo
echo "Finished."
echo "Master project folder:"
echo "  ${MASTER_DIR}"
echo "Analysis pack:"
echo "  ${MASTER_DIR}/${BUNDLE}"
echo
echo "Seed count:"
count=$(find "${MASTER_DIR}/outputs/ENSEMBLE_RUNS" -maxdepth 1 -type d -name 'seed_*' | wc -l)
echo "  ${count}"
