#!/usr/bin/env bash
set -euo pipefail
rm -rf outputs OOS_results ranking_results SR_test_results OOS_fixed_cache
