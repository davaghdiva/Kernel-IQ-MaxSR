"""Aggregate seed-level outputs for the Kernel-IQ maximum-Sharpe ensemble."""
from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Aggregate Kernel-IQ ensemble outputs.")
    parser.add_argument("--ensemble-root", type=str, default=None)
    return parser.parse_args()


def _resolve_roots(args: argparse.Namespace) -> tuple[Path, Path]:
    ensemble_root = Path(args.ensemble_root) if args.ensemble_root else PROJECT_DIR / "outputs" / "ENSEMBLE_RUNS"
    if not ensemble_root.is_absolute():
        ensemble_root = PROJECT_DIR / ensemble_root
    out_dir = ensemble_root / "_ensemble_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    return ensemble_root, out_dir


def _find_seed_dirs(root: Path) -> list[Path]:
    return sorted([p for p in root.glob("seed_*") if p.is_dir()])


def _infer_method_col(df: pd.DataFrame) -> str:
    for c in ["Method", "method", "Estimator", "Strategy", "Unnamed: 0"]:
        if c in df.columns:
            return c
    return df.columns[0]


def _infer_rank_col(df: pd.DataFrame) -> str:
    candidates = []
    for c in df.columns:
        lc = c.lower()
        if "rank" in lc:
            score = -10 if ("aggregate" in lc or "overall" in lc or "total" in lc) else 0
            candidates.append((score, c))
    if not candidates:
        raise RuntimeError(f"Could not infer a rank column from: {list(df.columns)}")
    candidates.sort(key=lambda x: x[0])
    return candidates[0][1]


def _read_metric_matrix(path: Path, seed: int, value_name: str) -> pd.DataFrame:
    df = pd.read_csv(path, index_col=0)
    df.index = [str(x) for x in df.index]
    df.columns = [str(c).replace("$", "").strip() for c in df.columns]
    long_df = df.reset_index(names="Metric").melt(id_vars="Metric", var_name="Method", value_name=value_name)
    long_df[value_name] = pd.to_numeric(long_df[value_name], errors="coerce")
    long_df["seed"] = seed
    return long_df


def _read_concentration_means(seed_dir: Path, seed: int) -> pd.DataFrame | None:
    oos_dir = seed_dir / "OOS_results"
    if not oos_dir.exists():
        return None
    rows = []
    for file_path in sorted(oos_dir.glob("*_concentration.csv")):
        method = file_path.stem.replace("_concentration", "")
        try:
            df = pd.read_csv(file_path)
        except Exception:
            continue
        if df.empty:
            continue
        metric_cols = [c for c in df.columns if c not in {"port", "date"}]
        for col in metric_cols:
            values = pd.to_numeric(df[col], errors="coerce").dropna()
            if values.empty:
                continue
            rows.append({
                "seed": seed,
                "Method": method,
                "Metric": col,
                "Value": float(values.mean()),
                "MedianValue": float(values.median()),
                "Q25Value": float(values.quantile(0.25)),
                "Q75Value": float(values.quantile(0.75)),
                "N": int(values.size),
            })
    return pd.DataFrame(rows) if rows else None


def _summarise_long(df: pd.DataFrame, value_col: str, metric_col: str, out_dir: Path, out_name: str) -> pd.DataFrame | None:
    if df.empty:
        return None
    summary = (df.dropna(subset=[value_col]).groupby(["Method", metric_col])[value_col]
        .agg(mean="mean", median="median", std="std", q25=lambda s: s.quantile(0.25), q75=lambda s: s.quantile(0.75), n="count")
        .reset_index())
    summary.to_csv(out_dir / out_name, index=False)
    return summary


def main() -> None:
    args = _parse_args()
    ensemble_root, out_dir = _resolve_roots(args)
    seed_dirs = _find_seed_dirs(ensemble_root)
    if not seed_dirs:
        raise RuntimeError(f"No seed_* folders found under {ensemble_root}")

    rank_frames = []
    for sd in seed_dirs:
        seed = int(sd.name.replace("seed_", ""))
        path = sd / "ranking_results" / "overall_ranking.csv"
        if not path.exists():
            print(f"[warn] Missing {path}")
            continue
        df = pd.read_csv(path)
        mcol = _infer_method_col(df); rcol = _infer_rank_col(df)
        df = df.rename(columns={mcol: "Method", rcol: "AggregateRank"})[["Method", "AggregateRank"]]
        df["AggregateRank"] = pd.to_numeric(df["AggregateRank"], errors="coerce")
        df["seed"] = seed
        rank_frames.append(df)
    if not rank_frames:
        raise RuntimeError("No overall_ranking.csv files were found/read successfully.")
    ranks = pd.concat(rank_frames, ignore_index=True)
    best_by_seed = ranks.assign(min_rank=ranks.groupby("seed")["AggregateRank"].transform("min")).assign(is_best=lambda x: x["AggregateRank"] == x["min_rank"])
    p_best = (best_by_seed[best_by_seed["is_best"]].groupby("Method")["seed"].nunique().div(best_by_seed["seed"].nunique()).mul(100.0).rename("P_best_%").reset_index())
    rank_summary = (ranks.groupby("Method")["AggregateRank"].agg(mean="mean", median="median", std="std", q25=lambda s: s.quantile(0.25), q75=lambda s: s.quantile(0.75), n="count").reset_index().merge(p_best, on="Method", how="left").sort_values(["mean", "median"], ascending=True))
    rank_summary.to_csv(out_dir / "ensemble_rank_summary.csv", index=False)

    metric_long_frames_full = []; metric_long_frames_rank = []; pmr_long_frames = []
    for sd in seed_dirs:
        seed = int(sd.name.replace("seed_", ""))
        parsed_full = sd / "ranking_results" / "parsed_metrics_full.csv"
        parsed_rank = sd / "ranking_results" / "parsed_metrics.csv"
        pmr_path = sd / "ranking_results" / "per_metric_ranks.csv"
        if parsed_full.exists(): metric_long_frames_full.append(_read_metric_matrix(parsed_full, seed, "Value"))
        elif parsed_rank.exists(): metric_long_frames_full.append(_read_metric_matrix(parsed_rank, seed, "Value"))
        else: print(f"[warn] Missing parsed metrics for {sd.name}")
        if parsed_rank.exists(): metric_long_frames_rank.append(_read_metric_matrix(parsed_rank, seed, "Value"))
        if pmr_path.exists(): pmr_long_frames.append(_read_metric_matrix(pmr_path, seed, "RankValue"))
    if metric_long_frames_full:
        metrics_full = pd.concat(metric_long_frames_full, ignore_index=True)
        _summarise_long(metrics_full, "Value", "Metric", out_dir, "ensemble_metric_summary_long.csv")
        sharpe_rows = metrics_full[metrics_full["Metric"].str.lower().str.contains("sharpe", na=False)].copy()
        if not sharpe_rows.empty: _summarise_long(sharpe_rows, "Value", "Metric", out_dir, "ensemble_sharpe_like_metrics.csv")
    if metric_long_frames_rank:
        _summarise_long(pd.concat(metric_long_frames_rank, ignore_index=True), "Value", "Metric", out_dir, "ensemble_metric_summary_rank_scope_long.csv")
    if pmr_long_frames:
        pmr_summary = _summarise_long(pd.concat(pmr_long_frames, ignore_index=True), "RankValue", "Metric", out_dir, "ensemble_per_metric_rank_summary_long.csv")
        if pmr_summary is not None:
            pmr_summary.rename(columns={"Metric": "MetricRank"}, inplace=True)
            pmr_summary.to_csv(out_dir / "ensemble_per_metric_rank_summary_long.csv", index=False)

    concentration_frames = []
    for sd in seed_dirs:
        seed = int(sd.name.replace("seed_", ""))
        cdf = _read_concentration_means(sd, seed)
        if cdf is not None and not cdf.empty:
            concentration_frames.append(cdf)
    if concentration_frames:
        conc_by_seed = pd.concat(concentration_frames, ignore_index=True)
        conc_by_seed.to_csv(out_dir / "ensemble_concentration_by_seed_long.csv", index=False)
        conc_summary = (conc_by_seed.groupby(["Method", "Metric"])["Value"]
            .agg(mean="mean", median="median", std="std", q25=lambda s: s.quantile(0.25), q75=lambda s: s.quantile(0.75), n="count")
            .reset_index())
        conc_summary.to_csv(out_dir / "ensemble_concentration_summary_long.csv", index=False)

    print(f"\nDone. Outputs written to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
