from __future__ import annotations

import argparse
import shutil
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Merge seed folders from other Kernel-IQ project copies into this project.")
    parser.add_argument("sources", nargs="+", help="Project folders to merge from.")
    parser.add_argument("--replace", action="store_true", help="Replace existing seed folders if present.")
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    dest_root = PROJECT_DIR / "outputs" / "ENSEMBLE_RUNS"
    dest_root.mkdir(parents=True, exist_ok=True)
    copied = 0
    skipped = 0
    for src_project in args.sources:
        src_root = Path(src_project).resolve() / "outputs" / "ENSEMBLE_RUNS"
        if not src_root.exists():
            print(f"[merge] Missing source ensemble root: {src_root}")
            continue
        for seed_dir in sorted(src_root.glob("seed_*")):
            if not seed_dir.is_dir():
                continue
            dest = dest_root / seed_dir.name
            if dest.exists():
                if args.replace:
                    shutil.rmtree(dest)
                else:
                    skipped += 1
                    continue
            shutil.copytree(seed_dir, dest)
            copied += 1
    print(f"[merge] copied={copied}; skipped={skipped}; destination={dest_root}")


if __name__ == "__main__":
    main()
