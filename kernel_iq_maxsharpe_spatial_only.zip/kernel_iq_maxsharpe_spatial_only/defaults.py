"""
Name    : defaults.py
Author  : William Smyth
Contact : drwss.academy@gmail.com
Date    : 26/03/2026
Desc    : central parameter configuration for the Kernel-IQ (WIQ) project.
"""
import os

DEFAULTS = dict(
    # data universe
    n_assets   = 10,

    # rolling experiment settings
    lookback   = 20,          # dependence lookback T (rows)
    wiq_m      = 4,           # scaling window multiplier m (scaling window length mT)

    # transaction/optimisation settings
    cost_bps   = 10.0,        # turnover penalty (bps) in optimiser objective

    # Part-2 output settings
    diq_output_dir      = "OOS_results",

    # Optuna settings
    # - gs_sre_optuna.py uses n_trials_gs_sre
    # - wiq_mvo.py uses n_trials_wiq
    seed            = 260370,
    n_trials_gs_sre = 100,
    n_trials_wiq    = 500,

    # in-sample window (tuning) and out-of-sample window for Part 2
    # In-sample tuning EVALUATION window. Any WIQ long-vol warm-up is loaded
    # before begin_date so that begin_date is the first scored IS month.
    # The default calendar assumes a price history beginning no later than 1987-12.
    # Under that assumption, 1995-01 is the earliest clean 10-year scored
    # in-sample window that preserves the 80-month WIQ warm-up.
    begin_date = "1995-01",
    end_date   = "2004-12",
    part2_begin_date = None,     # None => end_date + 1 month
    part2_end_date   = "2024-12",

    # evaluation alignment / fairness controls
    tuning_use_prehistory_warmup = True, # load pre-begin_date history so IS scoring truly begins at begin_date
    align_tuning_eval_with_wiq = True,   # GS_opt and SRE_opt are scored only on WIQ-feasible IS dates
    part2_use_prehistory_warmup = True,  # load pre-Part-2 history so realised OOS begins at part2_begin_date

    # data files
    prices_csv = "./prices_multi_asset_master.csv",
    rf_csv     = "./DGS3MO_monthly_rf.csv",

    # risk-free settings
    rf_frequency      = "M",                 # used only if interpretation == "annualized_yield"
    rf_align_method   = "ffill",             # {"ffill","bfill"}
    rf_interpretation = "monthly_effective", # {"monthly_effective","annualized_yield"}
    rf_column         = None,                # None => first column

    # temporal sequencing (shared convention)
    gamma_mode = "signed",   # {"signed","raw"}; sign selects which edge is favoured when "signed"
    u_gamma    = 0.00,       # upper bound for abs(gamma)
    a_floor    = 0.00,       # small floor in temporal weights (0 disables)

    # ------------------------
    # Kernel-IQ (WIQ) defaults
    # ------------------------
    wiq_eta_L    = 0.30,
    wiq_eta_B    = 0.50,
    wiq_eta_R    = 0.30,
    wiq_delta_L  = 2.0,
    wiq_delta_R  = 2.0,
    wiq_c        = 0.05,
    wiq_gamma    = 0.0,
    wiq_epsilon  = 0.0,

    # WIQ Optuna export
    wiq_params_json = "wiq_params.json",
    wiq_oos_diagnostics_csv = "wiq_oos_delta_diagnostics.csv",

    # ranking policy for refreshed MaxSR runs
    # "legacy_all" reproduces the old equal-weight all-metric style.
    # "maxsr_native" applies the refreshed official profile below.
    ranking_profile = "maxsr_native",
    ranking_metrics_maxsharpe = [
        "Sharpe Ratio",
        "Annualized Return (%)",
        "Cumulative Return (%)",
        "Annualized STD (%)",
        "Maximum Drawdown (%)",
        "Monthly 95% VaR (%)",
        "Monthly 95% Expected Shortfall (%)",
        "Sortino Ratio",
        "Calmar Ratio",
        "Turnover",
    ],
    ranking_metric_weights_maxsharpe = {
        "Sharpe Ratio": 2.0,
        "Annualized Return (%)": 1.0,
        "Cumulative Return (%)": 1.0,
        "Annualized STD (%)": 1.0,
        "Maximum Drawdown (%)": 1.0,
        "Monthly 95% VaR (%)": 1.0,
        "Monthly 95% Expected Shortfall (%)": 1.0,
        "Sortino Ratio": 1.0,
        "Calmar Ratio": 1.0,
        "Turnover": 1.0,
    },
)

# ====================================
# Kernel-IQ canonical specifications
# ====================================
# select: "prod" (stable baseline) or "research" (potentially adaptive + skew)
wiq_spec = DEFAULTS.get("wiq_spec", "research")  # "prod"|"research"

WIQ_SPEC_PROD = dict(
    # T policy
    wiq_T_mode="q_ratio",      # "fixed"|"q_ratio"
    wiq_q=2.0,                 # T_live = ceil(wiq_q * N)

    # scale window
    wiq_m=int(DEFAULTS.get("wiq_m", 4)),

    # vol scaling
    wiq_vol_mode="rolling_mT", # "rolling_mT"|"ewma"

    # centering
    wiq_center_method="mean",  # "mean"|"median"|"zero"

    # eta policy
    wiq_eta_mode="4eta",            # "3eta"|"4eta"
    wiq_eta_body_equalize=True,     # True => eta_B_pos = eta_B_neg = eta_B
    wiq_eta_body_param="plusminus", # "plusminus"|"direct" (ignored when equalize=True)
    wiq_eta_delta_max=0.20,         # ignored when equalize=True

    # defaults for direct mode (only used if wiq_eta_body_param == "direct")
    wiq_eta_B_pos=0.50,
    wiq_eta_B_neg=0.50,
)

WIQ_SPEC_RESEARCH = dict(
    # T policy
    wiq_T_mode="q_ratio",
    wiq_q=2.0,

    # scale window (slightly longer to support EWMA inside the scale window)
    wiq_m=max(int(DEFAULTS.get("wiq_m", 4)), 4),

    # vol scaling (local EWMA inside the scale window)
    wiq_vol_mode="rolling_mT", #"rolling_mT" or "ewma"
    wiq_ewma_halflife_mode="proportional_to_T",  # "fixed"|"proportional_to_T"
    wiq_ewma_halflife_factor=1.0,                # half-life = factor * T_live
    wiq_ewma_halflife=None,                      # used only if halflife_mode == "fixed"

    # centering
    wiq_center_method="mean", #"mean"|"median"|"zero"

    # eta policy (controlled learnable asymmetry)
    wiq_eta_mode="4eta",
    wiq_eta_body_equalize=True,     #True amounts to 3eta
    wiq_eta_body_param="plusminus", #"plusminus"|"?"|"direct"
    wiq_eta_delta_max=0.20,

    # defaults for direct mode (only used if wiq_eta_body_param == "direct")
    wiq_eta_B_pos=0.50,
    wiq_eta_B_neg=0.50,
)

WIQ_SPECS = {"prod": WIQ_SPEC_PROD, "research": WIQ_SPEC_RESEARCH}

if wiq_spec not in WIQ_SPECS:
    raise ValueError(f"wiq_spec must be one of {list(WIQ_SPECS)}, got: {wiq_spec!r}")

# apply the chosen WIQ spec into DEFAULTS
DEFAULTS.update(WIQ_SPECS[wiq_spec])


# ==========================================================
# Linux/CLI command-line overrides
# ==========================================================
# These overrides are operational only. They allow the experiment to be run
# from the command line without editing defaults.py.

def _env_bool(value: str) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _apply_env_overrides() -> None:
    override_specs = {
        "DIQ_N_ASSETS": ("n_assets", int),
        "DIQ_LOOKBACK": ("lookback", int),
        "DIQ_WIQ_M": ("wiq_m", int),
        "DIQ_WIQ_Q": ("wiq_q", float),
        "DIQ_COST_BPS": ("cost_bps", float),
        "DIQ_SEED": ("seed", int),
        "WIQ_N_TRIALS": ("n_trials_wiq", int),
        "GS_SRE_N_TRIALS": ("n_trials_gs_sre", int),
        "DIQ_BEGIN_DATE": ("begin_date", str),
        "DIQ_END_DATE": ("end_date", str),
        "DIQ_PART2_BEGIN_DATE": ("part2_begin_date", str),
        "DIQ_PART2_END_DATE": ("part2_end_date", str),
        "DIQ_PRICES_CSV": ("prices_csv", str),
        "DIQ_RF_CSV": ("rf_csv", str),
        "DIQ_RF_INTERPRETATION": ("rf_interpretation", str),
        "DIQ_RF_ALIGN_METHOD": ("rf_align_method", str),
    }
    for env_name, (key, caster) in override_specs.items():
        if env_name in os.environ and os.environ[env_name] != "":
            DEFAULTS[key] = caster(os.environ[env_name])

    bool_specs = {
        "DIQ_TUNING_USE_PREHISTORY_WARMUP": "tuning_use_prehistory_warmup",
        "DIQ_ALIGN_TUNING_EVAL_WITH_WIQ": "align_tuning_eval_with_wiq",
        "DIQ_PART2_USE_PREHISTORY_WARMUP": "part2_use_prehistory_warmup",
    }
    for env_name, key in bool_specs.items():
        if env_name in os.environ and os.environ[env_name] != "":
            DEFAULTS[key] = _env_bool(os.environ[env_name])

    if "DIQ_RANKING_PROFILE" in os.environ and os.environ["DIQ_RANKING_PROFILE"]:
        DEFAULTS["ranking_profile"] = os.environ["DIQ_RANKING_PROFILE"]
    else:
        DEFAULTS["ranking_profile"] = "maxsr_native"


_apply_env_overrides()
