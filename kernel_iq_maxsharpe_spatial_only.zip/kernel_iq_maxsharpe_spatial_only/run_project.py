"""Run the Kernel-IQ maximum-Sharpe ensemble pipeline."""
from __future__ import annotations

import argparse
import subprocess
import sys


def run_step(cmd: list[str]) -> None:
    pretty = " ".join(cmd)
    print(f"\n[run_project] Starting: {pretty}\n")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {result.returncode}: {pretty}")
    print(f"\n[run_project] Completed: {pretty}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Kernel-IQ maximum-Sharpe project.")
    parser.add_argument("--seed-start", type=int, default=1000)
    parser.add_argument("--num-seeds", type=int, default=100)
    parser.add_argument("--seeds", type=int, nargs="*", default=None)
    parser.add_argument("--fresh", action="store_true", help="Delete outputs before running.")
    parser.add_argument("--wiq-trials", type=int, default=None)
    parser.add_argument("--gs-sre-trials", type=int, default=None)
    parser.add_argument("--skip-sr-tests", action="store_true", help="Skip Sharpe-ratio comparison tests.")
    parser.add_argument("--sr-mode", choices=["off", "light", "full"], default="light")
    parser.add_argument("--sr-boot", type=int, default=None)
    parser.add_argument("--sr-comparators", type=str, default=None)
    parser.add_argument("--sr-verbose", action="store_true")
    parser.add_argument("--no-fixed-cache", action="store_true")
    parser.add_argument("--prices-csv", type=str, default=None)
    parser.add_argument("--rf-csv", type=str, default=None)
    parser.add_argument("--n-assets", type=int, default=None)
    parser.add_argument("--lookback", type=int, default=None)
    parser.add_argument("--wiq-q", type=float, default=None)
    parser.add_argument("--wiq-m", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ensemble_cmd = [sys.executable, "run_ensemble.py"]
    if args.fresh:
        ensemble_cmd.append("--fresh")
    if args.seeds is not None and len(args.seeds) > 0:
        ensemble_cmd.append("--seeds")
        ensemble_cmd.extend(str(s) for s in args.seeds)
    else:
        ensemble_cmd.extend(["--seed-start", str(args.seed_start), "--num-seeds", str(args.num_seeds)])
    for flag, value in [
        ("--wiq-trials", args.wiq_trials),
        ("--gs-sre-trials", args.gs_sre_trials),
        ("--sr-mode", args.sr_mode),
        ("--sr-boot", args.sr_boot),
        ("--sr-comparators", args.sr_comparators),
        ("--prices-csv", args.prices_csv),
        ("--rf-csv", args.rf_csv),
        ("--n-assets", args.n_assets),
        ("--lookback", args.lookback),
        ("--wiq-q", args.wiq_q),
        ("--wiq-m", args.wiq_m),
    ]:
        if value is not None:
            ensemble_cmd.extend([flag, str(value)])
    if args.skip_sr_tests:
        ensemble_cmd.append("--skip-sr-tests")
    if args.sr_verbose:
        ensemble_cmd.append("--sr-verbose")
    if args.no_fixed_cache:
        ensemble_cmd.append("--no-fixed-cache")
    run_step(ensemble_cmd)
    run_step([sys.executable, "aggregate_ensemble.py"])
    print("[run_project] Full project completed.")


if __name__ == "__main__":
    main()
