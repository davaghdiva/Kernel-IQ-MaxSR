from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent
FIXED_METHODS = {"HC", "LS1", "LS2", "LS3", "LS4", "LS5", "NLS6", "NLS7", "NLS8", "CRE", "SRE", "GS1", "GS2", "GS3"}
SEED_VARYING_METHODS = {"WIQ", "GS_opt", "SRE_opt"}
SERIES_SUFFIXES = ("value", "return", "turnover")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a compact upload-friendly analysis pack from Kernel-IQ ensemble outputs.")
    parser.add_argument("--project-root", type=str, default=str(PROJECT_DIR))
    parser.add_argument("--output-root", type=str, default=None, help="Defaults to <project>/analysis_packs")
    parser.add_argument("--pack-name", type=str, default=None, help="Base name for the pack directory/zip. Default uses a timestamp.")
    parser.add_argument("--skip-aggregate", action="store_true", help="Do not rerun aggregate_ensemble.py before packing.")
    parser.add_argument("--no-timeseries", action="store_true", help="Skip compact OOS time-series exports.")
    parser.add_argument("--no-zip", action="store_true", help="Create the pack directory only and do not create a zip archive.")
    return parser.parse_args()


def _seed_dirs(ensemble_root: Path) -> list[Path]:
    return sorted([p for p in ensemble_root.glob("seed_*") if p.is_dir()])


def _seed_from_dir(seed_dir: Path) -> int:
    return int(seed_dir.name.replace("seed_", ""))


def _safe_read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _safe_read_csv(path: Path, **kwargs) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        return pd.read_csv(path, **kwargs)
    except Exception:
        return None


def _long_from_matrix(path: Path, seed: int, value_name: str) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path, index_col=0)
    except Exception:
        return None
    df.index = [str(x) for x in df.index]
    df.columns = [str(c).replace("$", "").strip() for c in df.columns]
    long_df = df.reset_index(names="Metric").melt(id_vars="Metric", var_name="Method", value_name=value_name)
    long_df[value_name] = pd.to_numeric(long_df[value_name], errors="coerce")
    long_df["seed"] = seed
    return long_df


def _summarise_wiq_diagnostics(path: Path, seed: int) -> dict | None:
    df = _safe_read_csv(path)
    if df is None:
        return None
    out: dict[str, object] = {"seed": seed, "rows": int(len(df))}
    if "date" in df.columns and not df.empty:
        out["date_min"] = str(df["date"].iloc[0])
        out["date_max"] = str(df["date"].iloc[-1])
    for col in df.select_dtypes(include="number").columns.tolist():
        series = pd.to_numeric(df[col], errors="coerce").dropna()
        if series.empty:
            continue
        out[f"mean__{col}"] = float(series.mean())
        out[f"median__{col}"] = float(series.median())
        out[f"q25__{col}"] = float(series.quantile(0.25))
        out[f"q75__{col}"] = float(series.quantile(0.75))
    return out


def _series_long_from_file(path: Path, seed: int | None, method: str, series_type: str) -> pd.DataFrame | None:
    df = _safe_read_csv(path)
    if df is None:
        return None
    date_col = "date" if "date" in df.columns else df.columns[0]
    value_cols = [c for c in df.columns if c != date_col]
    if not value_cols:
        return None
    long_df = df.melt(id_vars=[date_col], value_vars=value_cols, var_name="column", value_name="value")
    long_df = long_df.rename(columns={date_col: "date"})
    long_df["method"] = method
    long_df["series_type"] = series_type
    if seed is not None:
        long_df["seed"] = seed
    cols = (["seed"] if seed is not None else []) + ["method", "series_type", "date", "column", "value"]
    return long_df[cols]


def _append_json_rows(rows: list[dict], path: Path, seed: int, payload_name: str) -> None:
    payload = _safe_read_json(path)
    if payload is None:
        return
    row = {"seed": seed, "payload": payload_name}
    row.update(pd.json_normalize(payload, sep="__").to_dict(orient="records")[0])
    rows.append(row)


def _copy_if_exists(src: Path, dst: Path) -> None:
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _write_csv(df: pd.DataFrame | None, path: Path) -> None:
    if df is None or df.empty:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _run_aggregate(project_root: Path) -> None:
    subprocess.run([sys.executable, str(project_root / "aggregate_ensemble.py")], cwd=str(project_root), check=True)


def _write_pack_manifest(pack_dir: Path, project_root: Path) -> None:
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "experiment": "maximum_sharpe",
        "project_root": str(project_root),
        "pack_purpose": "Condensed upload-friendly Kernel-IQ analysis bundle",
    }
    (pack_dir / "pack_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def _write_pack_readme(pack_dir: Path) -> None:
    text = """Kernel-IQ analysis pack
=======================

This folder is a condensed analysis bundle generated from a completed Kernel-IQ maximum-Sharpe ensemble run. It is intended to be small enough to upload while retaining the key information needed to reconstruct rankings, parameter summaries, Sharpe-test outputs, concentration diagnostics, and compact time-series summaries.

Included:
- ensemble_summary/: aggregated ensemble summaries produced by aggregate_ensemble.py
- compact_exports/seed_manifest.csv
- compact_exports/wiq_params_by_seed.csv
- compact_exports/gs_opt_params_by_seed.csv
- compact_exports/sre_opt_params_by_seed.csv
- compact_exports/overall_ranking_by_seed_long.csv
- compact_exports/performance_metrics_by_seed_long.csv
- compact_exports/per_metric_ranks_by_seed_long.csv
- compact_exports/concentration_metrics_by_seed_long.csv
- compact_exports/wiq_is_diagnostics_summary_by_seed.csv
- compact_exports/sr_full_sample_sharpes_by_seed.csv, if present
- compact_exports/sr_pairwise_full_sample_results_by_seed.csv, if present
- compact_exports/sr_pairwise_rolling_results_by_seed.csv, if present
- compact OOS value/return/turnover time-series exports, if requested
- sample_seed_files/: representative JSON/CSV files from the first seed for quick inspection
"""
    (pack_dir / "README_analysis_pack.txt").write_text(text, encoding="utf-8")


def _concentration_long(seed_dir: Path, seed: int) -> pd.DataFrame | None:
    oos_dir = seed_dir / "OOS_results"
    rows = []
    if not oos_dir.exists():
        return None
    for file_path in sorted(oos_dir.glob("*_concentration.csv")):
        method = file_path.stem.replace("_concentration", "")
        df = _safe_read_csv(file_path)
        if df is None or df.empty:
            continue
        metric_cols = [c for c in df.columns if c not in {"port", "date"}]
        for col in metric_cols:
            vals = pd.to_numeric(df[col], errors="coerce").dropna()
            if vals.empty:
                continue
            rows.append({
                "seed": seed,
                "Method": method,
                "Metric": col,
                "Value": float(vals.mean()),
                "MedianValue": float(vals.median()),
                "Q25Value": float(vals.quantile(0.25)),
                "Q75Value": float(vals.quantile(0.75)),
                "N": int(vals.size),
            })
    return pd.DataFrame(rows) if rows else None


def _pack_ensemble(project_root: Path, pack_dir: Path, include_timeseries: bool, skip_aggregate: bool) -> None:
    ensemble_root = project_root / "outputs" / "ENSEMBLE_RUNS"
    seed_dirs = _seed_dirs(ensemble_root)
    if not seed_dirs:
        print(f"[analysis-pack] No seed_* folders under {ensemble_root}")
        return

    if not skip_aggregate:
        print("[analysis-pack] Running aggregate_ensemble.py ...")
        _run_aggregate(project_root)

    compact = pack_dir / "compact_exports"
    summary_dir = pack_dir / "ensemble_summary"
    sample_dir = pack_dir / "sample_seed_files"
    compact.mkdir(parents=True, exist_ok=True)
    summary_dir.mkdir(parents=True, exist_ok=True)
    sample_dir.mkdir(parents=True, exist_ok=True)

    ensemble_outputs = ensemble_root / "_ensemble_outputs"
    if ensemble_outputs.exists():
        for f in sorted(ensemble_outputs.glob("*.csv")):
            _copy_if_exists(f, summary_dir / f.name)

    manifest_rows: list[dict] = []
    wiq_rows: list[dict] = []
    gs_rows: list[dict] = []
    sre_rows: list[dict] = []
    rank_frames: list[pd.DataFrame] = []
    perf_frames: list[pd.DataFrame] = []
    pmr_frames: list[pd.DataFrame] = []
    conc_frames: list[pd.DataFrame] = []
    wiq_diag_rows: list[dict] = []
    sr_full_frames: list[pd.DataFrame] = []
    sr_pair_full_frames: list[pd.DataFrame] = []
    sr_pair_roll_frames: list[pd.DataFrame] = []
    fixed_timeseries: list[pd.DataFrame] = []
    seed_varying_timeseries: list[pd.DataFrame] = []

    first_seed = seed_dirs[0]
    for seed_dir in seed_dirs:
        seed = _seed_from_dir(seed_dir)

        manifest = _safe_read_json(seed_dir / "run_manifest.json")
        if manifest is not None:
            row = {"seed": seed}
            row.update(pd.json_normalize(manifest, sep="__").to_dict(orient="records")[0])
            manifest_rows.append(row)

        _append_json_rows(wiq_rows, seed_dir / "wiq_params.json", seed, "wiq_params")
        _append_json_rows(gs_rows, seed_dir / "gs_opt_params.json", seed, "gs_opt_params")
        _append_json_rows(sre_rows, seed_dir / "sre_opt_params.json", seed, "sre_opt_params")

        rank_df = _safe_read_csv(seed_dir / "ranking_results" / "overall_ranking.csv")
        if rank_df is not None:
            method_col = next((c for c in ["Method", "method", "Estimator", "Strategy", "Unnamed: 0"] if c in rank_df.columns), rank_df.columns[0])
            rank_col = next((c for c in rank_df.columns if "rank" in c.lower()), rank_df.columns[-1])
            rank_df = rank_df.rename(columns={method_col: "Method", rank_col: "AggregateRank"})
            rank_df["AggregateRank"] = pd.to_numeric(rank_df["AggregateRank"], errors="coerce")
            rank_df["seed"] = seed
            rank_frames.append(rank_df[["seed", "Method", "AggregateRank"]])

        perf_long = _long_from_matrix(seed_dir / "ranking_results" / "parsed_metrics_full.csv", seed, "Value")
        if perf_long is not None:
            perf_frames.append(perf_long)
        pmr_long = _long_from_matrix(seed_dir / "ranking_results" / "per_metric_ranks.csv", seed, "RankValue")
        if pmr_long is not None:
            pmr_frames.append(pmr_long)
        conc_long = _concentration_long(seed_dir, seed)
        if conc_long is not None:
            conc_frames.append(conc_long)

        diag_summary = _summarise_wiq_diagnostics(seed_dir / "wiq_is_best_diagnostics.csv", seed)
        if diag_summary is not None:
            wiq_diag_rows.append(diag_summary)

        for rel, frames in [
            (Path("SR_test_results/full_sample_sharpes.csv"), sr_full_frames),
            (Path("SR_test_results/pairwise_full_sample_results.csv"), sr_pair_full_frames),
            (Path("SR_test_results/pairwise_rolling_results.csv"), sr_pair_roll_frames),
        ]:
            df = _safe_read_csv(seed_dir / rel)
            if df is not None:
                df["seed"] = seed
                frames.append(df)

        if include_timeseries:
            oos_dir = seed_dir / "OOS_results"
            if oos_dir.exists():
                for suffix in SERIES_SUFFIXES:
                    for file_path in sorted(oos_dir.glob(f"*_{suffix}.csv")):
                        method = file_path.stem[: -(len(suffix) + 1)]
                        target = fixed_timeseries if method in FIXED_METHODS else seed_varying_timeseries
                        if method in FIXED_METHODS and seed_dir != first_seed:
                            continue
                        df_long = _series_long_from_file(file_path, None if method in FIXED_METHODS else seed, method, suffix)
                        if df_long is not None:
                            if method in FIXED_METHODS:
                                df_long["source_seed"] = _seed_from_dir(first_seed)
                            target.append(df_long)

    if manifest_rows:
        _write_csv(pd.DataFrame(manifest_rows).sort_values("seed"), compact / "seed_manifest.csv")
    if wiq_rows:
        _write_csv(pd.DataFrame(wiq_rows).sort_values("seed"), compact / "wiq_params_by_seed.csv")
    if gs_rows:
        _write_csv(pd.DataFrame(gs_rows).sort_values("seed"), compact / "gs_opt_params_by_seed.csv")
    if sre_rows:
        _write_csv(pd.DataFrame(sre_rows).sort_values("seed"), compact / "sre_opt_params_by_seed.csv")
    if rank_frames:
        _write_csv(pd.concat(rank_frames, ignore_index=True).sort_values(["seed", "AggregateRank", "Method"]), compact / "overall_ranking_by_seed_long.csv")
    if perf_frames:
        _write_csv(pd.concat(perf_frames, ignore_index=True).sort_values(["seed", "Metric", "Method"]), compact / "performance_metrics_by_seed_long.csv")
    if pmr_frames:
        _write_csv(pd.concat(pmr_frames, ignore_index=True).sort_values(["seed", "Metric", "RankValue", "Method"]), compact / "per_metric_ranks_by_seed_long.csv")
    if conc_frames:
        _write_csv(pd.concat(conc_frames, ignore_index=True).sort_values(["seed", "Metric", "Method"]), compact / "concentration_metrics_by_seed_long.csv")
    if wiq_diag_rows:
        _write_csv(pd.DataFrame(wiq_diag_rows).sort_values("seed"), compact / "wiq_is_diagnostics_summary_by_seed.csv")
    if sr_full_frames:
        _write_csv(pd.concat(sr_full_frames, ignore_index=True).sort_values(["seed", sr_full_frames[0].columns[0]]), compact / "sr_full_sample_sharpes_by_seed.csv")
    if sr_pair_full_frames:
        _write_csv(pd.concat(sr_pair_full_frames, ignore_index=True).sort_values("seed"), compact / "sr_pairwise_full_sample_results_by_seed.csv")
    if sr_pair_roll_frames:
        _write_csv(pd.concat(sr_pair_roll_frames, ignore_index=True).sort_values("seed"), compact / "sr_pairwise_rolling_results_by_seed.csv")
    if fixed_timeseries:
        _write_csv(pd.concat(fixed_timeseries, ignore_index=True).sort_values(["method", "series_type", "date"]), compact / "oos_fixed_timeseries_long.csv")
    if seed_varying_timeseries:
        _write_csv(pd.concat(seed_varying_timeseries, ignore_index=True).sort_values(["seed", "method", "series_type", "date"]), compact / "oos_seed_varying_timeseries_long.csv")

    for rel in [
        Path("run_manifest.json"),
        Path("wiq_params.json"),
        Path("gs_opt_params.json"),
        Path("sre_opt_params.json"),
        Path("wiq_is_best_diagnostics.csv"),
        Path("ranking_results/overall_ranking.csv"),
        Path("ranking_results/parsed_metrics_full.csv"),
        Path("ranking_results/per_metric_ranks.csv"),
        Path("SR_test_results/full_sample_sharpes.csv"),
        Path("SR_test_results/pairwise_full_sample_results.csv"),
        Path("SR_test_results/pairwise_rolling_results.csv"),
    ]:
        _copy_if_exists(first_seed / rel, sample_dir / rel.name)
    first_conc = next((first_seed / "OOS_results").glob("*_concentration.csv"), None) if (first_seed / "OOS_results").exists() else None
    if first_conc is not None:
        _copy_if_exists(first_conc, sample_dir / first_conc.name)

    inventory_rows = []
    for seed_dir in seed_dirs:
        seed = _seed_from_dir(seed_dir)
        inventory_rows.append({
            "seed": seed,
            "has_run_manifest": (seed_dir / "run_manifest.json").exists(),
            "has_wiq_params": (seed_dir / "wiq_params.json").exists(),
            "has_gs_opt_params": (seed_dir / "gs_opt_params.json").exists(),
            "has_sre_opt_params": (seed_dir / "sre_opt_params.json").exists(),
            "has_overall_ranking": (seed_dir / "ranking_results" / "overall_ranking.csv").exists(),
            "has_parsed_metrics_full": (seed_dir / "ranking_results" / "parsed_metrics_full.csv").exists(),
            "has_per_metric_ranks": (seed_dir / "ranking_results" / "per_metric_ranks.csv").exists(),
            "has_concentration": bool(list((seed_dir / "OOS_results").glob("*_concentration.csv"))) if (seed_dir / "OOS_results").exists() else False,
            "has_wiq_is_diag": (seed_dir / "wiq_is_best_diagnostics.csv").exists(),
            "has_sr_full": (seed_dir / "SR_test_results" / "full_sample_sharpes.csv").exists(),
            "has_sr_pair_full": (seed_dir / "SR_test_results" / "pairwise_full_sample_results.csv").exists(),
            "has_sr_pair_roll": (seed_dir / "SR_test_results" / "pairwise_rolling_results.csv").exists(),
        })
    _write_csv(pd.DataFrame(inventory_rows).sort_values("seed"), compact / "seed_file_inventory.csv")
    print(f"[analysis-pack] Packed ensemble from {len(seed_dirs)} seeds.")


def main() -> None:
    args = _parse_args()
    project_root = Path(args.project_root).resolve()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_name = args.pack_name or f"kernel_iq_analysis_pack_{timestamp}"
    output_root = Path(args.output_root).resolve() if args.output_root else (project_root / "analysis_packs")
    output_root.mkdir(parents=True, exist_ok=True)
    pack_dir = output_root / base_name
    if pack_dir.exists():
        shutil.rmtree(pack_dir)
    pack_dir.mkdir(parents=True, exist_ok=True)

    _write_pack_manifest(pack_dir, project_root)
    _write_pack_readme(pack_dir)

    _pack_ensemble(project_root=project_root, pack_dir=pack_dir, include_timeseries=not args.no_timeseries, skip_aggregate=args.skip_aggregate)

    if not args.no_zip:
        zip_path = shutil.make_archive(str(pack_dir), "zip", root_dir=str(pack_dir))
        print(f"[analysis-pack] Zip written to: {zip_path}")
    print(f"[analysis-pack] Pack directory: {pack_dir}")


if __name__ == "__main__":
    main()
