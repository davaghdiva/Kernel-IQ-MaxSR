"""Run a Kernel-IQ maximum-Sharpe ensemble."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = PROJECT_DIR / "outputs"
PIPELINE_CMD = [sys.executable, "run_wiq.py"]
KEY_SR_COMPARATORS = "GS1,GS2,GS_opt,LS1,LS2,LS3,LS5,HC,CRE"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a Kernel-IQ maximum-Sharpe seed ensemble.")
    parser.add_argument("--seed-start", type=int, default=1000)
    parser.add_argument("--num-seeds", type=int, default=100)
    parser.add_argument("--seeds", type=int, nargs="*", default=None)
    parser.add_argument("--fresh", action="store_true", help="Delete outputs before running.")
    parser.add_argument("--wiq-trials", type=int, default=None)
    parser.add_argument("--gs-sre-trials", type=int, default=None)
    parser.add_argument("--skip-sr-tests", action="store_true", help="Skip Sharpe-ratio comparison tests.")
    parser.add_argument("--sr-mode", choices=["off", "light", "full"], default="light")
    parser.add_argument("--sr-boot", type=int, default=None)
    parser.add_argument("--sr-comparators", type=str, default=None)
    parser.add_argument("--sr-verbose", action="store_true")
    parser.add_argument("--no-fixed-cache", action="store_true")
    parser.add_argument("--prices-csv", type=str, default=None)
    parser.add_argument("--rf-csv", type=str, default=None)
    parser.add_argument("--n-assets", type=int, default=None)
    parser.add_argument("--lookback", type=int, default=None)
    parser.add_argument("--wiq-q", type=float, default=None)
    parser.add_argument("--wiq-m", type=int, default=None)
    return parser.parse_args()


def _resolve_seed_list(args: argparse.Namespace) -> list[int]:
    if args.seeds:
        return list(dict.fromkeys(args.seeds))
    if args.num_seeds <= 0:
        raise ValueError("--num-seeds must be positive when --seeds is not supplied.")
    return list(range(args.seed_start, args.seed_start + args.num_seeds))


def _base_env(args: argparse.Namespace) -> dict[str, str]:
    env = os.environ.copy()
    sr_mode = "off" if args.skip_sr_tests else args.sr_mode
    env["DIQ_OUTPUT_ROOT"] = str(OUTPUT_ROOT)
    env["DIQ_FIXED_CACHE_DIR"] = str(OUTPUT_ROOT / "OOS_fixed_cache")
    env["WIQ_USE_FIXED_CACHE"] = "0" if args.no_fixed_cache else "1"
    env["WIQ_SR_MODE"] = sr_mode
    env["WIQ_SR_VERBOSE"] = "1" if args.sr_verbose else "0"
    if sr_mode == "off":
        env["DIQ_SKIP_SR_TESTS"] = "1"
    elif sr_mode == "light":
        env["DIQ_SKIP_SR_TESTS"] = "0"
        env["WIQ_SR_N_BOOT"] = str(args.sr_boot if args.sr_boot is not None else 1000)
        env["WIQ_SR_ROLLING_STEPS"] = "3"
        env["WIQ_SR_ROLLING_BOOTSTRAP"] = "0"
        env["WIQ_SR_FULL_BOOTSTRAP"] = "1"
        env["WIQ_SR_COMPARATORS"] = args.sr_comparators or KEY_SR_COMPARATORS
    else:
        env["DIQ_SKIP_SR_TESTS"] = "0"
        if args.sr_boot is not None:
            env["WIQ_SR_N_BOOT"] = str(args.sr_boot)
        if args.sr_comparators:
            env["WIQ_SR_COMPARATORS"] = args.sr_comparators
    optional_env = {
        "WIQ_N_TRIALS": args.wiq_trials,
        "GS_SRE_N_TRIALS": args.gs_sre_trials,
        "DIQ_PRICES_CSV": args.prices_csv,
        "DIQ_RF_CSV": args.rf_csv,
        "DIQ_N_ASSETS": args.n_assets,
        "DIQ_LOOKBACK": args.lookback,
        "DIQ_WIQ_Q": args.wiq_q,
        "DIQ_WIQ_M": args.wiq_m,
    }
    for key, value in optional_env.items():
        if value is not None:
            env[key] = str(value)
    return env


def _seed_env(base_env: dict[str, str], seed_dir: Path, seed: int) -> dict[str, str]:
    env = base_env.copy()
    env["DIQ_SEED"] = str(seed)
    env["DIQ_OUTPUT_DIR"] = str(seed_dir / "OOS_results")
    env["DIQ_RANKING_DIR"] = str(seed_dir / "ranking_results")
    env["DIQ_SR_TEST_DIR"] = str(seed_dir / "SR_test_results")
    env["WIQ_PARAMS_JSON"] = str(seed_dir / "wiq_params.json")
    env["WIQ_IS_DIAGNOSTICS_CSV"] = str(seed_dir / "wiq_is_best_diagnostics.csv")
    env["GS_OPT_PARAMS_JSON"] = str(seed_dir / "gs_opt_params.json")
    env["SRE_OPT_PARAMS_JSON"] = str(seed_dir / "sre_opt_params.json")
    return env


def _write_manifest(seed_dir: Path, args: argparse.Namespace, seed: int) -> None:
    sr_mode = "off" if args.skip_sr_tests else args.sr_mode
    manifest = {
        "experiment": "maximum_sharpe",
        "seed": seed,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "pipeline_cmd": PIPELINE_CMD,
        "parameter_learning_schedule": "fixed_in_sample_per_seed",
        "portfolio_rebalancing": "monthly",
        "used_fixed_cache_within_current_run": not bool(args.no_fixed_cache),
        "sharpe_test_mode": sr_mode,
        "sharpe_bootstrap_replications": args.sr_boot,
        "wiq_trials_override": args.wiq_trials,
        "gs_sre_trials_override": args.gs_sre_trials,
        "prices_csv_override": args.prices_csv,
        "rf_csv_override": args.rf_csv,
        "n_assets_override": args.n_assets,
        "lookback_override": args.lookback,
        "wiq_q_override": args.wiq_q,
        "wiq_m_override": args.wiq_m,
    }
    (seed_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def run_one_seed(args: argparse.Namespace, seed: int, base_env: dict[str, str]) -> None:
    seed_dir = OUTPUT_ROOT / "ENSEMBLE_RUNS" / f"seed_{seed}"
    if seed_dir.exists():
        shutil.rmtree(seed_dir)
    seed_dir.mkdir(parents=True, exist_ok=True)
    env = _seed_env(base_env, seed_dir, seed)
    print(f"\n=== Running seed={seed} ===")
    subprocess.run(PIPELINE_CMD, cwd=str(PROJECT_DIR), check=True, env=env)
    _write_manifest(seed_dir, args, seed)
    print(f"[ok] Seed {seed} saved to {seed_dir}")


def main() -> None:
    args = _parse_args()
    if args.fresh and OUTPUT_ROOT.exists():
        print(f"[run_ensemble] Removing existing output root: {OUTPUT_ROOT}")
        shutil.rmtree(OUTPUT_ROOT)
    (OUTPUT_ROOT / "ENSEMBLE_RUNS").mkdir(parents=True, exist_ok=True)
    seeds = _resolve_seed_list(args)
    print(f"[run_ensemble] Seeds to run: {seeds}")
    print(f"[run_ensemble] Output root: {OUTPUT_ROOT}")
    print(f"[run_ensemble] Sharpe-test mode: {'off' if args.skip_sr_tests else args.sr_mode}")
    base_env = _base_env(args)
    for seed in seeds:
        run_one_seed(args, seed, base_env)
    print(f"\n[run_ensemble] Complete. Outputs are under: {OUTPUT_ROOT / 'ENSEMBLE_RUNS'}")


if __name__ == "__main__":
    main()
