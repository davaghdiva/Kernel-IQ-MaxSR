"""
Name    : ranking_performance.py
Author  : William Smyth & Layla Abu Khalaf
Contact : drwss.academy@gmail.com
Date    : 26/12/2025
Desc    : aggregating performance across methods
          and metrics to obtain an overall winner.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pandas as pd

from defaults import DEFAULTS as _D
SCRIPT_DIR = Path(__file__).parent


def _resolve_oos_dir() -> Path:
    raw = os.environ.get("DIQ_OUTPUT_DIR", _D.get("diq_output_dir", "OOS_results"))
    p = Path(raw)
    return p if p.is_absolute() else (SCRIPT_DIR / p)


def _resolve_ranking_dir(oos_dir: Path) -> Path:
    raw = os.environ.get("DIQ_RANKING_DIR")
    if raw:
        p = Path(raw)
        return p if p.is_absolute() else (SCRIPT_DIR / p)
    if oos_dir.name == "OOS_results":
        return SCRIPT_DIR / "ranking_results"
    return SCRIPT_DIR / f"ranking_results__{oos_dir.name}"


OOS_DIR = _resolve_oos_dir()
INPUT_FILE = OOS_DIR / "performance.csv"
OUT_DIR = _resolve_ranking_dir(OOS_DIR)
OUT_DIR.mkdir(exist_ok=True)

HIGHER_BETTER = [
    "annualized return", "cumulative return",
    "sharpe", "sortino", "calmar",
]

LOWER_BETTER = [
    "annualized std", "std", "stdev", "vol", "volatility", "turnover",
    "drawdown", "max drawdown", "maximum drawdown",
    "var", "value at risk", "cvar", "expected shortfall", "es",
]

RISK_MAGNITUDE_KEYWORDS = [
    "drawdown", "max drawdown", "maximum drawdown",
    "var", "value at risk", "cvar", "expected shortfall", "es",
]

DEFAULT_MAXSR_METRICS = [
    "Sharpe Ratio",
    "Annualized Return (%)",
    "Cumulative Return (%)",
    "Annualized STD (%)",
    "Maximum Drawdown (%)",
    "Monthly 95% VaR (%)",
    "Monthly 95% Expected Shortfall (%)",
    "Sortino Ratio",
    "Calmar Ratio",
    "Turnover",
]

DEFAULT_MAXSR_WEIGHTS = {
    "Sharpe Ratio": 2.0,
    "Annualized Return (%)": 1.0,
    "Cumulative Return (%)": 1.0,
    "Annualized STD (%)": 1.0,
    "Maximum Drawdown (%)": 1.0,
    "Monthly 95% VaR (%)": 1.0,
    "Monthly 95% Expected Shortfall (%)": 1.0,
    "Sortino Ratio": 1.0,
    "Calmar Ratio": 1.0,
    "Turnover": 1.0,
}



def load_and_flatten(path: str | Path) -> pd.DataFrame:
    try:
        df = pd.read_csv(path, header=[0, 1], index_col=0)
        if not isinstance(df.columns, pd.MultiIndex):
            raise ValueError("Not a MultiIndex header")
    except Exception:
        df = pd.read_csv(path, header=0, index_col=0)

    if isinstance(df.columns, pd.MultiIndex):
        level0 = df.columns.get_level_values(0)
        level1 = df.columns.get_level_values(1)
        if len(set(level1)) > 1 and (len(set(level0)) == 1 or len(set(level0)) < len(set(level1))):
            df.columns = [str(x) for x in level1]
        else:
            df.columns = [str(x) for x in level0]
    else:
        df.columns = [str(c) for c in df.columns]

    df.columns = [c.replace("$", "").strip() for c in df.columns]
    return df


def _row_matches_any(name: str, keywords) -> bool:
    m = str(name).lower()
    return any(k in m for k in keywords)


def make_risk_magnitudes(df: pd.DataFrame) -> pd.DataFrame:
    df2 = df.copy()
    for row in df.index:
        if _row_matches_any(row, RISK_MAGNITUDE_KEYWORDS):
            df2.loc[row] = df2.loc[row].abs()
    return df2


def metric_direction(metric: str):
    m = metric.lower()
    if any(k in m for k in LOWER_BETTER):
        return True
    if any(k in m for k in HIGHER_BETTER):
        return False
    return None


def _ranking_profile() -> str:
    return str(_D.get("ranking_profile", "maxsr_native")).strip().lower()


def _selected_metrics(df: pd.DataFrame) -> tuple[list[str], dict[str, float], list[str]]:
    profile = _ranking_profile()
    all_metrics = [str(m) for m in df.index]

    if profile == "maxsr_native":
        requested = list(_D.get("ranking_metrics_maxsharpe", DEFAULT_MAXSR_METRICS))
        weights_raw = dict(_D.get("ranking_metric_weights_maxsharpe", DEFAULT_MAXSR_WEIGHTS))
        selected = [m for m in requested if m in all_metrics]
        dropped = [m for m in all_metrics if m not in selected]
        weights = {m: float(weights_raw.get(m, 1.0)) for m in selected}
        return selected, weights, dropped

    selected = all_metrics
    weights = {m: 1.0 for m in selected}
    return selected, weights, []


def rank_metrics(df: pd.DataFrame):
    selected_metrics, metric_weights, dropped_metrics = _selected_metrics(df)
    ranked_rows = {}
    unknown_metrics = []

    for row in selected_metrics:
        asc = metric_direction(str(row))
        if asc is None:
            unknown_metrics.append(str(row))
            continue
        ranked_rows[row] = df.loc[row].rank(ascending=asc, method="min")

    ranks_df = pd.DataFrame(ranked_rows).T
    if ranks_df.empty:
        warn_path = OUT_DIR / "unmapped_metrics.txt"
        with open(warn_path, "w", encoding="utf-8") as f:
            f.write("No metrics were recognized by the ranking rules.\n")
            f.write("Metrics considered for ranking:\n")
            for m in selected_metrics:
                f.write(f" - {m}\n")
        raise RuntimeError(f"No rankable metrics found. See details in {warn_path}")

    weight_ser = pd.Series({row: float(metric_weights.get(row, 1.0)) for row in ranks_df.index})
    weighted_ranks = ranks_df.mul(weight_ser, axis=0)
    agg = weighted_ranks.sum(axis=0).sort_values()

    method_table = pd.DataFrame({
        "Aggregate Rank (Lower=Better)": agg,
        "Metrics Used": len(ranks_df.index),
        "Total Rank Weight": float(weight_ser.sum()),
    }).sort_values("Aggregate Rank (Lower=Better)")

    meta = {
        "experiment": "maximum_sharpe",
        "ranking_profile": _ranking_profile(),
        "metrics_used": list(ranks_df.index),
        "metric_weights": {k: float(v) for k, v in weight_ser.to_dict().items()},
        "dropped_metrics": dropped_metrics,
        "unmapped_metrics": unknown_metrics,
    }

    return ranks_df, weighted_ranks, method_table, meta


def main():
    df_full = load_and_flatten(INPUT_FILE)
    df_for_ranking = make_risk_magnitudes(df_full)

    ranks_df, weighted_ranks_df, method_table, meta = rank_metrics(df_for_ranking)
    metrics_used = list(ranks_df.index)
    df_rank_scope = df_full.loc[metrics_used].copy()

    df_full.to_csv(OUT_DIR / "parsed_metrics_full.csv")
    df_rank_scope.to_csv(OUT_DIR / "parsed_metrics.csv")
    ranks_df.to_csv(OUT_DIR / "per_metric_ranks.csv")
    weighted_ranks_df.to_csv(OUT_DIR / "per_metric_weighted_ranks.csv")
    method_table.to_csv(OUT_DIR / "overall_ranking.csv")
    with open(OUT_DIR / "ranking_scope.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    if meta.get("unmapped_metrics"):
        warn_path = OUT_DIR / "unmapped_metrics.txt"
        with open(warn_path, "w", encoding="utf-8") as f:
            f.write("The following requested metrics were present but not ranked (no direction rule matched):\n")
            for m in meta["unmapped_metrics"]:
                f.write(f" - {m}\n")

    print("\n=== Ranking complete ===")
    print(f"Files saved under {OUT_DIR.resolve()}")
    print(f"Ranking profile: {meta['ranking_profile']}")
    print(f"Metrics used for ranking: {meta['metrics_used']}")
    print("\nTop 5 methods:")
    print(method_table.head(5)["Aggregate Rank (Lower=Better)"])
    print("\nBottom 3 methods:")
    print(method_table.tail(3)["Aggregate Rank (Lower=Better)"])


if __name__ == "__main__":
    main()
