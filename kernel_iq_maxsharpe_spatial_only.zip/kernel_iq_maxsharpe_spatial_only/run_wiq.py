"""Run one Kernel-IQ pipeline for a selected objective and seed."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
FIXED_METHODS = ["HC", "LS1", "LS2", "LS3", "LS4", "LS5", "NLS6", "NLS7", "NLS8", "CRE", "SRE", "GS1", "GS2", "GS3"]
METHOD_FILE_SUFFIXES = ("value", "return", "trans", "turnover", "concentration")


def _resolve_oos_dir() -> Path:
    raw = os.environ.get("DIQ_OUTPUT_DIR", "OOS_results")
    p = Path(raw)
    return p if p.is_absolute() else BASE_DIR / p


def _resolve_fixed_cache_dir() -> Path:
    raw = os.environ.get("DIQ_FIXED_CACHE_DIR")
    if raw:
        p = Path(raw)
        return p if p.is_absolute() else BASE_DIR / p
    return BASE_DIR / "outputs" / "OOS_fixed_cache"


def run_step(script_name: str, extra_env: dict[str, str] | None = None) -> None:
    script_path = BASE_DIR / script_name
    if not script_path.is_file():
        raise FileNotFoundError(f"Could not find {script_name} in {BASE_DIR}")
    print(f"\n[runner] Starting {script_name} ...\n")
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    result = subprocess.run([sys.executable, str(script_path)], cwd=str(BASE_DIR), env=env)
    if result.returncode != 0:
        raise RuntimeError(f"{script_name} failed with exit code {result.returncode}")
    print(f"\n[runner] Completed {script_name}.\n")


def _method_output_paths(oos_dir: Path, method_name: str) -> list[Path]:
    return [oos_dir / f"{method_name}_{suffix}.csv" for suffix in METHOD_FILE_SUFFIXES]


def _clear_oos_dir(oos_dir: Path) -> None:
    if oos_dir.exists():
        shutil.rmtree(oos_dir)
    oos_dir.mkdir(parents=True, exist_ok=True)


def _cache_exists(cache_dir: Path) -> bool:
    return all((cache_dir / f"{method}_{suffix}.csv").exists() for method in FIXED_METHODS for suffix in METHOD_FILE_SUFFIXES)


def _copy_fixed_outputs_to_cache(oos_dir: Path, cache_dir: Path) -> None:
    cache_dir.mkdir(parents=True, exist_ok=True)
    for method in FIXED_METHODS:
        for src in _method_output_paths(oos_dir, method):
            if src.exists():
                shutil.copy2(src, cache_dir / src.name)
    print(f"[runner] Fixed-method cache refreshed in {cache_dir}")


def _preload_fixed_cache_into_oos(oos_dir: Path, cache_dir: Path) -> None:
    oos_dir.mkdir(parents=True, exist_ok=True)
    for method in FIXED_METHODS:
        for suffix in METHOD_FILE_SUFFIXES:
            src = cache_dir / f"{method}_{suffix}.csv"
            if not src.exists():
                raise FileNotFoundError(f"Missing cached fixed-method file: {src}")
            shutil.copy2(src, oos_dir / src.name)
    print(f"[runner] Preloaded fixed-method cache into {oos_dir}")


def main() -> None:
    oos_dir = _resolve_oos_dir()
    cache_dir = _resolve_fixed_cache_dir()
    use_fixed_cache = os.environ.get("WIQ_USE_FIXED_CACHE", "0").strip() == "1"
    skip_sr_tests = os.environ.get("DIQ_SKIP_SR_TESTS", "0").strip() == "1"
    print(f"[runner] OOS output dir: {oos_dir}")
    print(f"[runner] Fixed cache dir: {cache_dir}")
    run_step("gs_sre_optuna.py")
    run_step("wiq_mvo.py")
    if use_fixed_cache:
        if _cache_exists(cache_dir):
            _clear_oos_dir(oos_dir)
            _preload_fixed_cache_into_oos(oos_dir, cache_dir)
            run_step("diq_mvo.py", extra_env={"DIQ_RUN_MODE": "seed_varying_only"})
        else:
            _clear_oos_dir(oos_dir)
            run_step("diq_mvo.py", extra_env={"DIQ_RUN_MODE": "all"})
            _copy_fixed_outputs_to_cache(oos_dir, cache_dir)
    else:
        _clear_oos_dir(oos_dir)
        run_step("diq_mvo.py", extra_env={"DIQ_RUN_MODE": "all"})
    for script in ["diq_mvo_performance.py", "ranking_performance.py"]:
        run_step(script)
    if skip_sr_tests:
        print("[runner] Skipping wiq_sr_tests.py")
    else:
        run_step("wiq_sr_tests.py")
    print("\n[runner] All stages completed successfully.")


if __name__ == "__main__":
    main()
