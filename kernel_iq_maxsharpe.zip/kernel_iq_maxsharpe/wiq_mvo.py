"""
Name    : wiq_mvo.py
Author  : William Smyth
Contact : drwss.academy@gmail.com
Date    : 26/03/2026
Desc    : Optuna tuning for Kernel-IQ (WIQ) in the maximum-Sharpe portfolio experiment.
"""

from __future__ import annotations

import json
import os
from typing import Any

import numpy as np
import pandas as pd

from defaults import DEFAULTS
from mvo_utils import (
    BacktestConfig,
    MVOSettings,
    _load_prices_subset,
    _load_rf_aligned,
    annualized_sharpe,
    annualized_variance,
    annualized_volatility,
    solve_max_sharpe,
)
from wiq_cov import wishart_iq_covariance

try:
    import optuna
    _HAVE_OPTUNA = True
except Exception:
    optuna = None
    _HAVE_OPTUNA = False


def _script_dir() -> str:
    return os.path.abspath(os.path.dirname(__file__)) if "__file__" in globals() else os.getcwd()


def _read_json(path_or_name: str) -> dict:
    path = path_or_name if os.path.isabs(path_or_name) else os.path.join(_script_dir(), path_or_name)
    with open(path, "r") as f:
        return json.load(f)


def _write_json(obj: dict, path_or_name: str) -> str:
    path = path_or_name if os.path.isabs(path_or_name) else os.path.join(_script_dir(), path_or_name)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
    return path



# -----------------------------
# windowing policies
# -----------------------------

def _clip_eval_window(ret_ser: pd.Series) -> pd.Series:
    b = DEFAULTS.get("begin_date")
    e = DEFAULTS.get("end_date")
    if b or e:
        return ret_ser.loc[b:e]
    return ret_ser


def _load_insample_prices() -> pd.DataFrame:
    """Load in-sample prices, optionally with prehistory warm-up.

    begin_date / end_date define the *scored* in-sample evaluation window. When
    tuning_use_prehistory_warmup=True, enough history is loaded before begin_date
    so that WIQ can first score exactly at begin_date rather than sacrificing the
    first T_scale months of the stated training window.
    """
    prcs = _load_prices_subset(DEFAULTS["prices_csv"], n_assets=DEFAULTS.get("n_assets"))
    b = DEFAULTS.get("begin_date")
    e = DEFAULTS.get("end_date")
    if not (b or e):
        return prcs

    if b and bool(DEFAULTS.get("tuning_use_prehistory_warmup", True)):
        begin_period = pd.Period(str(b), freq="M")
        T_live = _effective_T_live(prcs.shape[1])
        warmup_rets = _effective_T_scale(T_live)
        load_begin_period = begin_period - (warmup_rets + 1)
        prcs = prcs.loc[str(load_begin_period):e]

        rets = prcs.pct_change().dropna(axis=0)
        if len(rets) <= warmup_rets:
            raise ValueError(
                f"Insufficient in-sample history for WIQ warm-up. Need more than {warmup_rets} return rows before first scored month {b}."
            )
        first_scored = pd.Period(rets.index[warmup_rets], freq="M")
        if first_scored > begin_period:
            raise ValueError(
                f"Insufficient prehistory to make begin_date={b} the first scored IS month. "
                f"Earliest feasible scored month with the available data is {first_scored}."
            )
        return prcs

    return prcs.loc[b:e]


def _effective_T_live(n_assets: int) -> int:
    mode = str(DEFAULTS.get("wiq_T_mode", "fixed"))
    if mode == "q_ratio":
        q = float(DEFAULTS.get("wiq_q", 2.0))
        return int(np.ceil(q * float(n_assets)))
    return int(DEFAULTS["lookback"])


def _effective_T_scale(T_live: int) -> int:
    m = int(DEFAULTS.get("wiq_m", 3))
    return int(m * int(T_live))


def _body_asymmetry_active() -> bool:
    return (
        str(DEFAULTS.get("wiq_eta_mode", "3eta")) == "4eta"
        and (not bool(DEFAULTS.get("wiq_eta_body_equalize", True)))
        and str(DEFAULTS.get("wiq_eta_body_param", "plusminus")) == "plusminus"
    )


# allowed keys for passing into wishart_iq_covariance
WIQ_ALLOWED = {
    "eta_L", "eta_B", "eta_R",
    "delta_L", "delta_R",
    "gamma", "epsilon", "threshold_c",
    "center_method", "gamma_mode", "gamma_max",
    "a_floor", "a_mass_normalize",
    "vol_mode", "ewma_halflife_mode", "ewma_halflife", "ewma_halflife_factor",
    "eta_mode", "eta_body_equalize", "eta_body_param", "eta_delta_max",
    "delta_B", "eta_B_pos", "eta_B_neg",
}


# -----------------------------
# Backtest (objective engine)
# -----------------------------

def backtest_wiq_mvo(
    prcs: pd.DataFrame,
    wiq_params: dict,
    bt_cfg: BacktestConfig,
    diagnostics_path: str | None = None,
) -> pd.Series:
    """
    Monthly rebalanced portfolio backtest.

    Returns a Series of realised monthly excess returns on the optimisation basis.
    """
    prcs = prcs.copy()
    rets = prcs.pct_change().dropna(axis=0)
    prcs = prcs.iloc[1:]  # align

    rf_series = _load_rf_aligned(rets.index)
    rets_excess = rets.sub(rf_series, axis=0) if rf_series is not None else rets
    optimisation_rets = rets_excess

    nT, p = optimisation_rets.shape
    T_live = _effective_T_live(p)
    T_scale = _effective_T_scale(T_live)

    if nT < T_scale + 2:
        return pd.Series(dtype=float)

    settings = MVOSettings(min_w=0.0, max_w=1.0, cost_bps=float(bt_cfg.cost_bps))
    prev_w: np.ndarray | None = None

    wiq_call = {k: v for k, v in wiq_params.items() if k in WIQ_ALLOWED}

    port_rets = []
    port_idx = []
    diag_rows: list[dict[str, Any]] = []

    for t in range(T_scale, nT):
        sub_scale = optimisation_rets.iloc[t - T_scale: t]
        live_opt = sub_scale.iloc[-T_live:]

        dbg: dict[str, Any] = {}
        cov_df = wishart_iq_covariance(sub_scale, T_live, **wiq_call, debug_out=dbg)

        if diagnostics_path is not None and isinstance(dbg.get("delta_eff_summary", None), dict):
            end_date = optimisation_rets.index[t]
            s = dbg["delta_eff_summary"]
            rm = dbg.get("region_mass_summary", {}) if isinstance(dbg.get("region_mass_summary", None), dict) else {}
            diag_rows.append({
                "date": str(end_date),
                "T_live": int(T_live),
                "T_scale": int(T_scale),
                "wiq_m": int(DEFAULTS.get("wiq_m", 3)),
                "delta_L": float(wiq_call.get("delta_L")),
                "delta_R": float(wiq_call.get("delta_R")),
                **s,
                **rm,
            })

        w = solve_max_sharpe(
            returns_excess_window=live_opt,
            cov_monthly=cov_df.values.astype(float),
            prev_weights=prev_w,
            settings=settings,
        )
        prev_w = w.copy()

        r_tp1 = float(np.dot(w, optimisation_rets.iloc[t].values.astype(float)))
        port_rets.append(r_tp1)
        port_idx.append(optimisation_rets.index[t])

    if diagnostics_path is not None and len(diag_rows) > 0:
        diag_df = pd.DataFrame(diag_rows)
        write_header = not os.path.exists(diagnostics_path)
        diag_df.to_csv(diagnostics_path, mode=("w" if write_header else "a"), header=write_header, index=False)

    return pd.Series(port_rets, index=pd.DatetimeIndex(port_idx), name="wiq_port_returns")


# -----------------------------
# Sampling spaces
# -----------------------------

def _wiq_base_structural() -> dict[str, Any]:
    return dict(
        threshold_c=float(DEFAULTS.get("wiq_c", 0.05)),
        epsilon=float(DEFAULTS.get("wiq_epsilon", 0.0)),
        center_method=str(DEFAULTS.get("wiq_center_method", "mean")),
        gamma_mode=str(DEFAULTS.get("gamma_mode", "signed")),
        gamma_max=float(DEFAULTS.get("u_gamma", 0.10)),
        a_floor=float(DEFAULTS.get("a_floor", 0.0)),
        a_mass_normalize=True,
        vol_mode=str(DEFAULTS.get("wiq_vol_mode", "rolling_mT")),
        ewma_halflife_mode=str(DEFAULTS.get("wiq_ewma_halflife_mode", "fixed")),
        ewma_halflife=(None if DEFAULTS.get("wiq_ewma_halflife", None) is None else float(DEFAULTS.get("wiq_ewma_halflife"))),
        ewma_halflife_factor=float(DEFAULTS.get("wiq_ewma_halflife_factor", 1.0)),
        eta_mode=str(DEFAULTS.get("wiq_eta_mode", "3eta")),
        eta_body_equalize=bool(DEFAULTS.get("wiq_eta_body_equalize", True)),
        eta_body_param=str(DEFAULTS.get("wiq_eta_body_param", "plusminus")),
        eta_delta_max=float(DEFAULTS.get("wiq_eta_delta_max", 0.20)),
        eta_B_pos=float(DEFAULTS.get("wiq_eta_B_pos", 0.50)),
        eta_B_neg=float(DEFAULTS.get("wiq_eta_B_neg", 0.50)),
    )


def _sample_wiq(trial: "optuna.trial.Trial") -> dict[str, Any]:
    eta_L = trial.suggest_float("eta_L", 0.0, 1.0)
    eta_B = trial.suggest_float("eta_B", 0.0, 1.0)
    eta_R = trial.suggest_float("eta_R", 0.0, 1.0)
    delta_L = trial.suggest_float("delta_L", 1.0, 2.0, step=0.2)
    delta_R = trial.suggest_float("delta_R", 1.0, 2.0, step=0.2)

    u = float(DEFAULTS.get("u_gamma", 0.10))
    gamma = trial.suggest_float("gamma", -u, u, step=0.02)

    wiq = dict(
        eta_L=float(eta_L),
        eta_B=float(eta_B),
        eta_R=float(eta_R),
        delta_L=float(delta_L),
        delta_R=float(delta_R),
        gamma=float(gamma),
        **_wiq_base_structural(),
    )
    if _body_asymmetry_active():
        dmax = float(DEFAULTS.get("wiq_eta_delta_max", 0.20))
        wiq["delta_B"] = float(trial.suggest_float("delta_B", -dmax, dmax, step=0.02))
    return wiq



# -----------------------------
# Tuning routines
# -----------------------------

def _objective_value_from_returns(ret_series: pd.Series) -> float:
    return float(annualized_sharpe(ret_series, rf=None))


def _study_direction() -> str:
    return "maximize"


def _best_metric_key() -> str:
    return "best_insample_sharpe"


def tune_wiq_only(prcs: pd.DataFrame, bt_cfg: BacktestConfig, *, n_trials: int, seed: int) -> tuple[dict, float]:
    if not _HAVE_OPTUNA:
        raise RuntimeError("Optuna is required for tuning.")

    def objective(trial: "optuna.trial.Trial") -> float:
        wiq = _sample_wiq(trial)
        ret_ser = backtest_wiq_mvo(prcs, wiq, bt_cfg)
        return _objective_value_from_returns(_clip_eval_window(ret_ser))

    study = optuna.create_study(direction=_study_direction())
    study.sampler = optuna.samplers.TPESampler(seed=seed, multivariate=True, group=True)
    study.pruner = optuna.pruners.MedianPruner(n_startup_trials=max(5, int(0.2 * n_trials)))

    seed_trial = {
        "eta_L": float(DEFAULTS.get("wiq_eta_L", 0.30)),
        "eta_B": float(DEFAULTS.get("wiq_eta_B", 0.50)),
        "eta_R": float(DEFAULTS.get("wiq_eta_R", 0.30)),
        "delta_L": float(DEFAULTS.get("wiq_delta_L", 2.0)),
        "delta_R": float(DEFAULTS.get("wiq_delta_R", 2.0)),
        "gamma": float(DEFAULTS.get("wiq_gamma", 0.0)),
    }
    if _body_asymmetry_active():
        seed_trial["delta_B"] = 0.0
    study.enqueue_trial(seed_trial)

    study.optimize(objective, n_trials=n_trials)

    best_wiq = _sample_wiq(study.best_trial)
    return best_wiq, float(study.best_value)



# -----------------------------
# Main entry
# -----------------------------

def main() -> None:
    if not _HAVE_OPTUNA:
        raise RuntimeError("Optuna is not available but is required for wiq_mvo tuning.")

    prcs = _load_insample_prices()

    bt_cfg = BacktestConfig(
        lookback=int(DEFAULTS["lookback"]),
        cost_bps=float(DEFAULTS.get("cost_bps", 10.0)),
    )

    n_trials = int(os.environ.get("WIQ_N_TRIALS", DEFAULTS.get("n_trials_wiq", 300)))
    seed = int(DEFAULTS.get("seed", 260370))
    params_json = str(os.environ.get("WIQ_PARAMS_JSON", DEFAULTS.get("wiq_params_json", "wiq_params.json")))

    metric_key = _best_metric_key()
    metric_label = "Sharpe"

    print(f"[wiq_mvo] WIQ tuning, trials={n_trials} ...")
    best_wiq, best_val = tune_wiq_only(prcs, bt_cfg, n_trials=n_trials, seed=seed)
    best_wiq[metric_key] = float(best_val)

    _write_json(best_wiq, params_json)
    print(f"[wiq_mvo] Wrote WIQ params to: {os.path.join(_script_dir(), params_json)}")
    print(f"[wiq_mvo] Best in-sample {metric_label} (WIQ) = {best_val:.6f}")

    if bool(DEFAULTS.get("wiq_write_is_diagnostics", True)):
        is_name = str(os.environ.get("WIQ_IS_DIAGNOSTICS_CSV", DEFAULTS.get("wiq_is_diagnostics_csv", "wiq_is_best_diagnostics.csv")))
        is_path = is_name if os.path.isabs(is_name) else os.path.join(_script_dir(), is_name)
        try:
            if os.path.exists(is_path):
                os.remove(is_path)
        except Exception:
            pass
        _ = backtest_wiq_mvo(prcs, best_wiq, bt_cfg, diagnostics_path=is_path)
        print(f"[wiq_mvo] Wrote IS diagnostics (frozen WIQ) to: {is_path}")

    print("[wiq_mvo] Done.")


if __name__ == "__main__":
    main()
